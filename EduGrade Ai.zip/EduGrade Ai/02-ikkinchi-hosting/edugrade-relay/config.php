<?php
// PHP 7.4. Bu fayl faqat serverda o‘qiladi, brauzerga qiymat chiqarmaydi.
return [
    'api_key' => 'CHANGE_ME_GEMINI_API_KEY',
    // Parol menejeri bilan 64 ta tasodifiy harf/raqam yarating.
    // Asosiy saytdagi GEMINI_RELAY_TOKEN bilan aynan bir xil bo‘lsin.
    'token' => 'CHANGE_ME_RANDOM_64_CHARACTER_TOKEN',
    'model' => 'gemini-3.1-flash-lite',
    'timeout' => 120,
    'requests_per_minute' => 30,
];
