<?php
declare(strict_types=1);
// Standalone PHP 7.4+ relay. No database, sessions or third-party packages.
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function relay_fail(int $status, string $message): void
{
    http_response_code($status);
    echo json_encode(['error'=>['message'=>$message]], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    relay_fail(405, 'Vositachi ishlayapti. Faqat asosiy saytdan tokenli POST so‘rovi qabul qilinadi.');
}

try {
    $config = require __DIR__ . '/config.php';
    if (!is_array($config)) relay_fail(503, 'Vositachi konfiguratsiyasi noto‘g‘ri.');
    $token = (string)($config['token'] ?? '');
    $key = (string)($config['api_key'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_-]{48,128}$/D', $token) || strpos($token, 'CHANGE_ME') !== false
        || !preg_match('/^[A-Za-z0-9._-]{20,300}$/D', $key) || strpos($key, 'CHANGE_ME') !== false) {
        relay_fail(503, 'Ikkinchi hostingdagi config.php faylida API kalit va maxfiy tokenni sozlang.');
    }
    $supplied = (string)($_SERVER['HTTP_X_EDUGRADE_RELAY_TOKEN'] ?? '');
    if (!hash_equals($token, $supplied)) relay_fail(401, 'Vositachi tokeni mos emas. Ikki hostingdagi tokenni tekshiring.');
    if (!function_exists('curl_init')) relay_fail(503, 'Ikkinchi hostingda PHP cURL yoqilmagan.');

    // A single fixed Google destination; callers cannot choose URLs or tools.
    $limit = 24 * 1024 * 1024; // 15 MB file plus base64 and JSON overhead.
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit) relay_fail(413, 'AI so‘rovi 24 MB dan oshdi.');
    $stream = fopen('php://input', 'rb');
    if ($stream === false) relay_fail(400, 'So‘rovni o‘qib bo‘lmadi.');
    $body = stream_get_contents($stream, $limit + 1);
    fclose($stream);
    if ($body === false || strlen($body) > $limit) relay_fail(413, 'AI so‘rovi juda katta.');
    $payload = json_decode($body, true);
    unset($body);
    if (!is_array($payload) || !isset($payload['input'])
        || (!is_string($payload['input']) && !is_array($payload['input']))) relay_fail(400, 'JSON input topilmadi.');
    $allowed = ['model','input','system_instruction','response_format','generation_config','store','stream'];
    if (array_diff(array_keys($payload), $allowed)) relay_fail(400, 'So‘rovda ruxsat berilmagan maydon bor.');
    if (($payload['model'] ?? '') !== ($config['model'] ?? '')) relay_fail(400, 'Model nomi ikki hostingda bir xil bo‘lishi kerak.');
    if (isset($payload['generation_config']) && !is_array($payload['generation_config'])) relay_fail(400, 'generation_config obyekt bo‘lishi kerak.');
    $payload['generation_config']['max_output_tokens'] = max(1, min(12000, (int)($payload['generation_config']['max_output_tokens'] ?? 1000)));
    $payload['store'] = false;
    $payload['stream'] = false;

    // Local storage works on shared hosts where /tmp is outside open_basedir.
    // PHP guard protects the counter even if Apache ignores the deny rule.
    $storage = __DIR__ . '/storage';
    if (!is_dir($storage) && !@mkdir($storage, 0750, true) && !is_dir($storage)) {
        relay_fail(503, 'edugrade-relay/storage papkasini yarating va PHP uchun yozish ruxsatini bering.');
    }
    $path = $storage . '/rate-limit.php';
    $handle = @fopen($path, 'c+');
    if (!$handle) relay_fail(503, 'edugrade-relay/storage papkasiga yozib bo‘lmadi. Papka egasi va yozish ruxsatini tekshiring.');
    if (!@flock($handle, LOCK_EX)) {
        fclose($handle);
        relay_fail(503, 'Hosting faylni qulflashga (flock) ruxsat bermadi. Hosting yordam xizmatiga murojaat qiling.');
    }
    @chmod($path, 0600);
    $guard = "<?php http_response_code(403); exit; ?>\n";
    $stored = (string)stream_get_contents($handle);
    $state = $stored === '' ? null : json_decode((string)substr($stored, strlen($guard)), true);
    if ($stored !== '' && (strpos($stored, $guard) !== 0 || !is_array($state)
        || !isset($state['window'], $state['count']))) {
        flock($handle, LOCK_UN);
        fclose($handle);
        relay_fail(503, 'storage/rate-limit.php hisoblagichi buzilgan. Faylni zaxiralab, olib tashlang va qayta sinang.');
    }
    $window = (int)floor(time() / 60);
    $count = is_array($state) && ($state['window'] ?? null) === $window ? (int)$state['count'] : 0;
    if ($count >= max(1, (int)($config['requests_per_minute'] ?? 30))) {
        flock($handle, LOCK_UN);
        fclose($handle);
        header('Retry-After: 60');
        relay_fail(429, 'Vositachining daqiqalik limiti tugadi. Bir daqiqadan keyin urinib ko‘ring.');
    }
    rewind($handle);
    $nextState = $guard . json_encode(['window'=>$window,'count'=>$count + 1]);
    $saved = ftruncate($handle, 0) && fwrite($handle, $nextState) === strlen($nextState) && fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    if (!$saved) relay_fail(503, 'Vositachi limit hisobini saqlay olmadi.');

    $timeout = max(5, min(150, (int)($config['timeout'] ?? 120)));
    @set_time_limit($timeout + 10);
    $ch = curl_init('https://generativelanguage.googleapis.com/v1beta/interactions');
    $raw = '';
    $tooLarge = false;
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'x-goog-api-key: ' . $key],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
        CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$raw, &$tooLarge): int {
            if (strlen($raw) + strlen($chunk) > 4 * 1024 * 1024) { $tooLarge = true; return 0; }
            $raw .= $chunk;
            return strlen($chunk);
        },
    ]);
    $sent = curl_exec($ch);
    $errno = curl_errno($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($tooLarge) relay_fail(502, 'Gemini javobi hajm limitidan oshdi.');
    if ($sent === false) relay_fail($errno === 28 ? 504 : 502, 'Vositachidan Gemini ulanishida xato. cURL kodi: ' . $errno);
    $data = json_decode($raw, true);
    if (!is_array($data)) relay_fail(502, 'Gemini JSON javob qaytarmadi.');
    if ($status < 200 || $status >= 300 || isset($data['error'])) {
        $message = (string)($data['error']['message'] ?? 'Gemini API xatosi.');
        $message = str_replace([$key, $token], '[yashirilgan]', $message);
        relay_fail($status >= 400 && $status <= 599 ? $status : 502, substr($message, 0, 2000));
    }
    http_response_code($status);
    echo $raw;
} catch (Throwable $error) {
    // Do not expose config, stack traces, keys or student answers.
    relay_fail(500, 'Vositachida ichki xato. PHP konfiguratsiyasi va fayllarni tekshiring.');
}
