# EduGrade AI — Online Test Platform

O‘qituvchilar uchun PHP 8.2 + MySQL asosidagi to‘liq online test platformasi. Login, ro‘yxatdan o‘tish, dashboard, dinamik test builder, public test havolasi, avtomatik scoring, AI yordamida yozma javoblarni baholash, BHO va o‘quvchilar natijalari diagrammasi mavjud.

Bosh sahifa EduGrade AI haqida to‘liq ma’lumot beradi: platforma imkoniyatlari, ishlash tartibi, qisqa yo‘riqnoma va Byte M1ners jamoasi bo‘limlari. “Bepul boshlash” va “Kirish” tugmalari bevosita ishlaydigan tizimga ulangan.

## Talablar

- PHP 8.2 yoki yangi
- MySQL 5.7+/MariaDB 10.4+
- PDO MySQL kengaytmasi
- PHP cURL kengaytmasi (AI baholash uchun)
- XAMPP yoki PHP built-in server

## Windows + XAMPP

1. Papkani `C:\xampp\htdocs\online-test-platform` ichiga ko‘chiring.
2. XAMPP orqali Apache va MySQL'ni ishga tushiring.
3. Brauzerda `http://localhost/online-test-platform/setup.php` ni oching.
4. Keyin `http://localhost/online-test-platform/public/` ni oching.

Subfolder orqali ishlatsangiz `config/config.php` ichidagi `app_url` qiymatini yoki `APP_URL` muhit o‘zgaruvchisini `http://localhost/online-test-platform/public` qilib belgilang.

## PHP built-in server

```bash
cd online-test-platform
php setup.php
php -S localhost:8000 -t public
```

Brauzer: `http://localhost:8000`

## Database sozlamalari

Standart qiymatlar:

```text
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=online_test_platform
DB_USER=root
DB_PASS=
```

Kerak bo‘lsa `config/config.php` ni tahrirlang yoki muhit o‘zgaruvchilaridan foydalaning. `setup.php` database va barcha jadvallarni yaratadi.

## Gemini API va yozma javoblarni baholash

1. `.env.example` faylidan nusxa olib, nomini `.env` qiling.
2. `GEMINI_API_KEY` qiymatiga Google AI Studio API kalitingizni kiriting.
3. Mavjud loyiha yangilanayotgan bo‘lsa AI uchun kerakli database ustunlari keyingi sahifa ochilishida avtomatik qo‘shiladi. Xohlasangiz `setup.php` ni qo‘lda ham ochishingiz mumkin.

```text
GEMINI_API_KEY=kalitingizni_shu_yerga_yozing
GEMINI_MODEL=gemini-3.8-flash
GEMINI_THINKING_LEVEL=low
GEMINI_TIMEOUT=45
SUPPORT_ADMIN_EMAIL=admin@example.com
```

API kalitni GitHub'ga yuklamang va `public/` papkaga yozmang. `.env` fayli `.gitignore` ichiga kiritilgan. Teacher test builderda “Yozma javob — AI baholaydi” turini tanlaydi, namunaviy javob va aniq mezon yozadi. AI imlo yoki tinish belgisi bilan emas, mazmun va mezon bilan baholaydi. Ishonchi past javoblar o‘qituvchi tekshiruvi uchun belgilanadi.

API ulanishini tekshirish uchun teacher hisobiga kirib `http://localhost:8000/api-test.php` sahifasini oching. XAMPP subfolder o‘rnatilishida manzil `http://localhost/online-test-platform/public/api-test.php` bo‘ladi.

### AI support yordamchisi

Hisobga kirgan foydalanuvchiga sahifaning pastki burchagida EduGrade yordamchisi ko‘rinadi. U sayt imkoniyatlari bo‘yicha qisqa javob beradi. AI yecha olmagan muammo suhbat tarixi bilan support murojaatiga aylantiriladi. `.env` dagi `SUPPORT_ADMIN_EMAIL` egasi yoki tizimdagi birinchi foydalanuvchi sidebar orqali “Support murojaatlari” sahifasini ochib, murojaatni ko‘radi va hal qilingan deb belgilaydi.

### Fayldan AI orqali test yaratish

“Test yaratish” sahifasida PDF, DOCX, TXT, JPG, PNG yoki WEBP fayl yuklash mumkin. Gemini fayldagi savol, variant, javob va ballarni tahrirlash formasiga ajratadi. Faylda yo‘q ma’lumotlar taxmin qilinmaydi — ular o‘qituvchi to‘ldirishi uchun bo‘sh qoladi. AI rasmga bog‘liq savolni aniqlasa, savol kartasida rasm yuklash eslatmasi chiqadi. Har bir savolga 5 MB gacha JPG, PNG yoki WEBP rasm biriktirish mumkin.

15 MB hujjat yuklash uchun XAMPP `php.ini` faylida quyidagilar kamida shunday bo‘lsin va Apache qayta ishga tushirilsin:

```ini
upload_max_filesize=16M
post_max_size=32M
```

### Prompt orqali AI test yaratish

Dashboarddagi “AI yordamida test yaratish” tugmasi alohida generator oynasini ochadi. O‘qituvchi mavzu va talablarni yozadi, ixtiyoriy rasm yuklaydi, test turi, maksimal ball, ball taqsimoti va savollar sonini tanlaydi. Gemini tayyorlagan loyiha mavjud test tahrirlash formasiga tushadi; u avtomatik nashr qilinmaydi va o‘qituvchi barcha savol, javob hamda ballarni tekshirib o‘zgartirishi mumkin.

## Foydalanish

1. `register.php` orqali o‘qituvchi hisobini yarating.
2. Dashboard'dan “Yangi test” ni bosing.
3. Test nomi, maksimal ball, savollar va variantlarni kiriting.
4. Bitta javobli savolda aynan 1 ta, ko‘p javoblida kamida 2 ta to‘g‘ri javob belgilang.
5. Savollar ballari maksimal ballga teng bo‘lganda testni nashr qiling.
6. Dashboard'dagi “Link” tugmasi bilan public havolani nusxalang.
7. O‘quvchi ism, familiya va sinfini kiritib testni yechadi.
8. Natija avtomatik hisoblanadi va o‘qituvchi “Natijalar” sahifasida ko‘radi.
9. “Excel yuklab olish” tugmasi orqali barcha yoki filtrlangan natijalarni `.xlsx` fayl qilib yuklab oladi.

## Muhim javob arxitekturasi

Single-answer input: `answers[QUESTION_ID]`  
Multiple-answer input: `answers[QUESTION_ID][]`

Shu sababli har bir savol alohida radio guruhga ega: 10 ta savolga 10 ta javob bir vaqtning o‘zida tanlangan holda qoladi.

## Test

`tests/answer_independence.html` faylini brauzerda oching. `PASS: 10/10 independent answers` ko‘rinishi kerak.

PHP o‘rnatilgan terminalda syntax tekshirish:

```bash
find . -name "*.php" -exec php -l {} \;
```

## Xavfsizlik

PDO prepared statements, CSRF token, XSS escaping, `password_hash`, `password_verify`, session ID regeneration, ownership tekshiruvi, secure public token, server-side validation va database transaction ishlatilgan.

## Troubleshooting

- `Access denied`: MySQL username/parolni tekshiring.
- `could not find driver`: PHP'da `pdo_mysql` extension'ni yoqing.
- CSS ochilmasa: `APP_URL` ni saytning `public` URL manziliga moslang.
- Test nashr qilinmasa: savollar ballari yig‘indisi maksimal ballga tengligini tekshiring.
