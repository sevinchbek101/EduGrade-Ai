<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_auth();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('dashboard.php');
verify_csrf();

$title = post_string('title');
$description = post_string('description');
$maxScore = (float)($_POST['max_score'] ?? 0);
$status = ($_POST['action'] ?? 'draft') === 'publish' ? 'published' : 'draft';
$questions = json_decode((string)($_POST['questions_json'] ?? '[]'), true);
$errors = [];
if ($title === '' || $maxScore <= 0) $errors[] = 'Test nomi va maksimal ballni to‘g‘ri kiriting.';
if (!is_array($questions) || !count($questions)) $errors[] = 'Kamida bitta savol qo‘shing.';

$sum = 0.0;
foreach ($questions as $index => $question) {
    $number = $index + 1;
    $type = in_array($question['type'] ?? '', ['single', 'multiple', 'written'], true) ? $question['type'] : '';
    $points = (float)($question['points'] ?? 0);
    if (trim((string)($question['text'] ?? '')) === '' || $points <= 0 || $type === '') $errors[] = "$number-savol to‘liq emas.";
    if ($type === 'written') {
        if (trim((string)($question['referenceAnswer'] ?? '')) === '') $errors[] = "$number-savol uchun namunaviy javob kiriting.";
        if (trim((string)($question['rubric'] ?? '')) === '') $errors[] = "$number-savol uchun baholash mezonini kiriting.";
    } else {
        $options = $question['options'] ?? [];
        $correct = array_filter($options, fn($option) => !empty($option['correct']));
        if (count($options) < 2 || count(array_filter($options, fn($option) => trim((string)($option['text'] ?? '')) !== '')) < 2) $errors[] = "$number-savolda kamida 2 ta variant bo‘lsin.";
        if ($type === 'single' && count($correct) !== 1) $errors[] = "$number-savolda aynan bitta to‘g‘ri javob tanlang.";
        if ($type === 'multiple' && count($correct) < 2) $errors[] = "$number-savolda kamida 2 ta to‘g‘ri javob tanlang.";
    }
    $sum += $points;
}
if ($status === 'published' && abs($sum - $maxScore) > .001) $errors[] = "Savollar ballari yig‘indisi $sum, maksimal ball esa $maxScore.";
if ($errors) {
    flash('danger', implode(' ', $errors));
    redirect(($_POST['test_id'] ?? '') ? 'edit-test.php?id=' . (int)$_POST['test_id'] : 'create-test.php');
}

function save_question_image(?string $dataUrl, ?string $existingPath): ?string
{
    if (!$dataUrl) return $existingPath && preg_match('#^assets/uploads/questions/[a-f0-9]{40}\.(?:jpg|png|webp)$#', $existingPath) ? $existingPath : null;
    if (!preg_match('#^data:(image/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$#', $dataUrl, $match)) throw new RuntimeException('Savol rasmi formati noto‘g‘ri.');
    $bytes = base64_decode($match[2], true);
    if ($bytes === false || strlen($bytes) > 5 * 1024 * 1024 || @getimagesizefromstring($bytes) === false) throw new RuntimeException('Savol rasmi 5 MB dan kichik JPG, PNG yoki WEBP bo‘lsin.');
    $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $directory = dirname(__DIR__) . '/assets/uploads/questions';
    if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) throw new RuntimeException('Rasm papkasini yaratib bo‘lmadi.');
    $fileName = bin2hex(random_bytes(20)) . '.' . $extensions[$match[1]];
    if (file_put_contents($directory . '/' . $fileName, $bytes, LOCK_EX) === false) throw new RuntimeException('Savol rasmini saqlab bo‘lmadi.');
    return 'assets/uploads/questions/' . $fileName;
}

$pdo = db();
try {
    $pdo->beginTransaction();
    $testId = (int)($_POST['test_id'] ?? 0);
    if ($testId) {
        if (!owned_test($testId)) throw new RuntimeException('Ruxsat yo‘q.');
        $update = $pdo->prepare('UPDATE tests SET title=?,description=?,max_score=?,status=? WHERE id=? AND user_id=?');
        $update->execute([$title, $description, $maxScore, $status, $testId, user()['id']]);
        $pdo->prepare('DELETE FROM questions WHERE test_id=?')->execute([$testId]);
    } else {
        $insertTest = $pdo->prepare('INSERT INTO tests(user_id,title,description,max_score,public_token,status) VALUES(?,?,?,?,?,?)');
        $insertTest->execute([user()['id'], $title, $description, $maxScore, bin2hex(random_bytes(32)), $status]);
        $testId = (int)$pdo->lastInsertId();
    }

    $insertQuestion = $pdo->prepare('INSERT INTO questions(test_id,question_text,question_type,points,sort_order,ai_reference_answer,ai_rubric,image_path) VALUES(?,?,?,?,?,?,?,?)');
    $insertOption = $pdo->prepare('INSERT INTO options(question_id,option_text,option_key,is_correct,sort_order) VALUES(?,?,?,?,?)');
    foreach ($questions as $index => $question) {
        $type = in_array($question['type'], ['single', 'multiple', 'written'], true) ? $question['type'] : 'single';
        $reference = $type === 'written' ? trim((string)($question['referenceAnswer'] ?? '')) : null;
        $rubric = $type === 'written' ? trim((string)($question['rubric'] ?? '')) : null;
        $imagePath = save_question_image(isset($question['imageData']) ? (string)$question['imageData'] : null, isset($question['imagePath']) ? (string)$question['imagePath'] : null);
        $insertQuestion->execute([$testId, trim((string)$question['text']), $type, (float)$question['points'], $index + 1, $reference, $rubric, $imagePath]);
        $questionId = (int)$pdo->lastInsertId();
        if ($type !== 'written') foreach ($question['options'] as $optionIndex => $option) {
            $insertOption->execute([$questionId, trim((string)$option['text']), chr(65 + $optionIndex), !empty($option['correct']) ? 1 : 0, $optionIndex + 1]);
        }
    }
    $pdo->commit();
    flash('success', $status === 'published' ? 'Test nashr qilindi.' : 'Qoralama saqlandi.');
    redirect('dashboard.php');
} catch (Throwable $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    flash('danger', 'Saqlashda xatolik: ' . $error->getMessage());
    redirect('dashboard.php');
}
