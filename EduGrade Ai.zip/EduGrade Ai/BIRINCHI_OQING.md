# EduGrade AI — to‘liq sayt va Gemini vositachisi

Bu faqat patch emas. `01-asosiy-sayt` papkasida yuborgan
BilimTest-online-test-platform (17).zip loyihangizning barcha fayllari va
Gemini relay integratsiyasi bor. `02-ikkinchi-hosting` vositachi kodidir.
Asosiy sayt PHP 8.1+ (8.2 tavsiya etiladi), vositachi PHP 7.4+ uchun.
Asl loyihada PHP 8.1 da qo‘shilgan `never` tipi bor.

## 1. Ikkinchi hosting — MyXvest (PHP 7.4.33)

`02-ikkinchi-hosting` ichidagi `edugrade-relay` papkasini
`server-check.php` turgan joyga yuklang. `.htaccess` va `.user.ini` fayllari
ham birga ko‘chsin. Eski saytni o‘chirish shart emas.

`edugrade-relay/config.php` faylida:

- `api_key`: tekshiruvda ishlagan Gemini kalitingizni yozing.
- `token`: parol menejerida yaratilgan 64 ta tasodifiy harf va raqamni yozing.
  A–Z, a–z, 0–9, `_`, `-` belgilaridan foydalanish mumkin. Google kaliti
  va token boshqa-boshqa qiymatlar. Tokenni asosiy saytga ham kiritasiz.
- `model`: `gemini-3.1-flash-lite` bo‘lib qolsin.

PHP terminal bo‘lsa, tokenni yaratish buyrug‘i:

```sh
php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'
```

CHANGE_ME o‘rniga o‘z qiymatlaringizni yozing, qo‘shtirnoqlarni saqlang.
API kalit va tokenni chatga yubormang.

Vositachi URL:
https://6a8ae2a6ef76c.myxvest1.ru/edugrade-relay/index.php

Oddiy brauzerda ochilganda HTTP 405 va tokenli POST kerakligi haqidagi
xabar normal. Haqiqiy tekshiruv asosiy saytdagi tugma orqali qilinadi.

## 2. Asosiy hosting — hozir ishlayotgan sayt

Avval saytingiz fayllari va bazasini zaxiralang.
`01-asosiy-sayt` papkasining ICHIDAGI barcha fayl va papkalarni hozirgi
loyiha ildiziga yuklang. `config`, `includes`, `public`, `database`
papkalari eski joylariga mos tushsin. Mavjud fayllarni yangilang;
butun eski papkani o‘chirib yubormang.

Mavjud `.env`, yuklangan rasmlar (`public/assets/uploads`) va MySQL
bazasini saqlang. Paketda haqiqiy `.env` yo‘q, faqat namunalari bor.
Mavjud sayt uchun `setup.php` ni QAYTA ISHGA TUSHIRMANG va bazani qayta
import qilmang. Ushbu yangilanish yangi DB sxemasini talab qilmaydi.

Mavjud `.env` dagi quyidagi qatorlarni yangilang yoki qo‘shing:

```dotenv
GEMINI_API_KEY=
GEMINI_RELAY_URL=https://6a8ae2a6ef76c.myxvest1.ru/edugrade-relay/index.php
GEMINI_RELAY_TOKEN=BU_YERGA_IKKINCHI_HOSTINGDAGI_64_BELGILI_TOKEN
GEMINI_MODEL=gemini-3.1-flash-lite
GEMINI_THINKING_LEVEL=low
GEMINI_TIMEOUT=135
```

Token config.php dagi `token` bilan aynan bir xil bo‘lsin. Qatorlarni
takrorlamang. APP_URL, DB_HOST, DB_NAME, DB_USER, DB_PASS va boshqa
sozlamalaringizni o‘zgartirmang. Google kaliti faqat ikkinchi hostingda.

Yangi, bo‘sh hostingga o‘rnatayotgan bo‘lsangiz, `.env.production.example`
dan `.env` nusxasini yarating va haqiqiy domen/MySQL ma’lumotlarini yozing.
Yangi baza o‘rnatilishi uchun `01-asosiy-sayt/SERVER_INSTALL_UZ.md` ni o‘qing.
U yerdagi eski bevosita Gemini sozlamalari o‘rniga ushbu relay sozlamalarini
qo‘llang. Ishlayotgan saytingiz uchun bu yangi o‘rnatish bosqichi kerak emas.

## 3. Ishlashini tekshirish

1. Asosiy saytda o‘qituvchi hisobiga kiring.
2. “AI API tekshiruvi”da “Vositachi / maxfiy token” va MyXvest URL ko‘rinsin.
3. Tekshirish tugmasini bosing: HTTP 200 va EDUGRADE_API_OK kuting.
4. Bitta yozma savolni baholash, fayldan import, AI test yaratish va support
   chatni sinang. Google kvotasi odatdagidek sarflanadi.
5. Ishlagach ikkinchi hostingdagi gemini-host-check.php va server-check.php
   diagnostika fayllarini olib tashlang.

Oldingi muvaffaqiyatsiz topshiriqlar avtomatik qayta baholanmaydi.
Sinov uchun yangi topshiriq yuboring.

## Muammo chiqsa

- 401: ikkala hostingdagi tokenni tekshiring. Hosting
  `X-Edugrade-Relay-Token` headerini uzatishi kerak.
- 404: papka joylashuvi yoki URL noto‘g‘ri.
- 400 model: ikki hostingda model nomi bir xil bo‘lsin.
- 400 location: Google ikkinchi hosting IP hududini ham rad etmoqda.
- 413: relay JSON chegarasi 24 MB; hosting post_max_size=25M,
  memory_limit=256M bo‘lsin. 15 MB fayl base64 da taxminan 20 MB bo‘ladi.
- 429: relay daqiqalik limiti yoki Google kvotasi. Xabar qaysi biri ekanini
  ko‘rsatadi. Relay standart limiti 30 so‘rov/daqiqa; uni oshirish Google
  kvotasini oshirmaydi.
- 503: config.php qiymatlari, cURL va vaqtinchalik papkaga yozish ruxsatini
  tekshiring. Google bandligi xabari bo‘lsa, keyinroq urinib ko‘ring.
- 504 / cURL 28: kutish vaqti tugadi; hosting vaqt chegaralarini tekshiring.
- cURL 60: hosting SSL/CA sertifikatlarini tuzatishi kerak, TLS tekshiruvini
  o‘chirmang.
- 500: hosting error logini tekshiring. Maxfiy qiymatlarni ulashmang.

`.user.ini` ishlamasa, PHP limitlarini hosting panelida belgilang.
`.htaccess` qoidalari Apache mos hosting uchun. PHP fayllar bajarilishi va
config.php manba kodi ommaga ochilmasligi shart.

## Nima o‘zgardi va nimalar tekshirildi

Asosiy koddagi uchta PHP fayl yangilandi: config/config.php,
includes/gemini.php, public/api-test.php. Barcha to‘rtta AI funksiya relay
orqali ishlashga moslangan. Saytning boshqa fayllari asl ZIP dan saqlangan.
Vositachi API kalitni brauzerga chiqarmaydi, token bilan tekshiradi, bitta
belgilangan Google endpointiga so‘rov yuboradi, TLS ni tekshiradi va
hajm/so‘rov limitlarini qo‘llaydi. Avtomatik takroriy so‘rov yo‘q.

PHP 7.4.33 va PHP 8.2 muhitlarida transporti sun’iy almashtirilgan sinovlar
o‘tdi. Batafsil: TEKSHIRUV.md. Haqiqiy ikki hosting orasidagi ulanish va
Google’ning baholash javobi o‘rnatilgandan keyin tekshiriladi.

Rasmiy API: https://ai.google.dev/gemini-api/docs/interactions-overview
