<?php
$required = array('pdo_mysql', 'curl', 'zip', 'fileinfo', 'mbstring');
$versionOk = version_compare(PHP_VERSION, '8.0.0', '>=');
$allOk = $versionOk;
$checks = array();
foreach ($required as $extension) {
    $enabled = extension_loaded($extension);
    $checks[] = array('name' => $extension, 'ok' => $enabled);
    if (!$enabled) $allOk = false;
}
?><!doctype html><html lang="uz"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EduGrade AI — server tekshiruvi</title><style>body{margin:0;background:#f3f6fb;color:#102a4b;font:14px Arial,sans-serif;display:grid;place-items:center;min-height:100vh}.card{width:min(560px,calc(100% - 32px));background:white;border:1px solid #dfe7f0;border-radius:18px;padding:28px;box-shadow:0 16px 45px #17365512}h1{margin:0 0 8px}.muted{color:#718197}.item{display:flex;justify-content:space-between;padding:13px 0;border-bottom:1px solid #edf1f5}.ok{color:#087c59}.bad{color:#bd334c}.notice{margin-top:20px;padding:14px;border-radius:10px;background:#fff5db;color:#805d16}.ready{background:#e8f8f1;color:#146e52}code{background:#eef2f7;padding:2px 5px;border-radius:4px}</style></head><body><main class="card"><h1>Server tekshiruvi</h1><p class="muted">Bu sahifa databasega ulanmasdan PHP holatini tekshiradi.</p><div class="item"><b>PHP versiyasi</b><strong class="<?=$versionOk?'ok':'bad'?>"><?=htmlspecialchars(PHP_VERSION)?> · <?=$versionOk?'Mos':'PHP 8.0+ kerak'?></strong></div><?php foreach($checks as $check):?><div class="item"><b><?=htmlspecialchars($check['name'])?></b><strong class="<?=$check['ok']?'ok':'bad'?>"><?=$check['ok']?'Yoqilgan':'Yoqilmagan'?></strong></div><?php endforeach?><div class="notice <?=$allOk?'ready':''?>"><?=$allOk?'Serverning PHP qismi tayyor. Endi .env ma’lumotlarini tekshirib setup.php ni oching.':'Hosting panelida PHP 8.2 ni tanlang va qizil ko‘rsatilgan kengaytmalarni yoqing.'?></div><p class="muted">Tekshiruv tugagach, xavfsizlik uchun <code>server-check.php</code> faylini o‘chiring.</p></main></body></html>
