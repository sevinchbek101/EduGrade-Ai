<?php
declare(strict_types=1);

function ensure_column(PDO $pdo, string $table, string $column, string $definition): void
{
    $dbName = app_config()['db']['name'];
    $check = $pdo->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND COLUMN_NAME=?');
    $check->execute([$dbName, $table, $column]);
    if (!(int)$check->fetchColumn()) $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
}

function run_ai_migration(PDO $pdo): void
{
    $version = '002_ai_written_answers';
    $pdo->exec('CREATE TABLE IF NOT EXISTS schema_migrations (version VARCHAR(100) PRIMARY KEY, applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    $check = $pdo->prepare('SELECT COUNT(*) FROM schema_migrations WHERE version=?');
    $check->execute([$version]);
    if (!(int)$check->fetchColumn()) {
        $pdo->exec("ALTER TABLE questions MODIFY question_type ENUM('single','multiple','written') NOT NULL");
        ensure_column($pdo, 'questions', 'ai_reference_answer', 'TEXT NULL AFTER sort_order');
        ensure_column($pdo, 'questions', 'ai_rubric', 'TEXT NULL AFTER ai_reference_answer');
        ensure_column($pdo, 'test_attempts', 'ai_review_pending', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER percentage');
        $pdo->exec('ALTER TABLE student_answers MODIFY option_id BIGINT UNSIGNED NULL');
        ensure_column($pdo, 'student_answers', 'answer_text', 'TEXT NULL AFTER option_id');
        ensure_column($pdo, 'student_answers', 'ai_score', 'DECIMAL(8,2) NULL AFTER answer_text');
        ensure_column($pdo, 'student_answers', 'ai_feedback', 'TEXT NULL AFTER ai_score');
        ensure_column($pdo, 'student_answers', 'ai_confidence', 'DECIMAL(5,4) NULL AFTER ai_feedback');
        ensure_column($pdo, 'student_answers', 'requires_review', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER ai_confidence');
        ensure_column($pdo, 'student_answers', 'ai_model', 'VARCHAR(80) NULL AFTER requires_review');
        $insert = $pdo->prepare('INSERT INTO schema_migrations(version) VALUES(?)');
        $insert->execute([$version]);
    }

    $mediaVersion = '003_question_images';
    $check->execute([$mediaVersion]);
    if (!(int)$check->fetchColumn()) {
        ensure_column($pdo, 'questions', 'image_path', 'VARCHAR(255) NULL AFTER ai_rubric');
        $insert = $pdo->prepare('INSERT INTO schema_migrations(version) VALUES(?)');
        $insert->execute([$mediaVersion]);
    }

    $supportVersion = '004_ai_support';
    $check->execute([$supportVersion]);
    if (!(int)$check->fetchColumn()) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS support_tickets (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            subject VARCHAR(255) NOT NULL,
            last_message TEXT NOT NULL,
            conversation_json MEDIUMTEXT NULL,
            status ENUM('open','resolved') NOT NULL DEFAULT 'open',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            CONSTRAINT fk_support_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX(user_id), INDEX(status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $insert = $pdo->prepare('INSERT INTO schema_migrations(version) VALUES(?)');
        $insert->execute([$supportVersion]);
    }

    $listeningVersion = '005_listening_audio';
    $check->execute([$listeningVersion]);
    if (!(int)$check->fetchColumn()) {
        ensure_column($pdo, 'tests', 'listening_text', 'TEXT NULL AFTER max_score');
        ensure_column($pdo, 'tests', 'listening_audio_path', 'VARCHAR(255) NULL AFTER listening_text');
        $insert = $pdo->prepare('INSERT INTO schema_migrations(version) VALUES(?)');
        $insert->execute([$listeningVersion]);
    }

    $listeningLanguageVersion = '006_listening_language';
    $check->execute([$listeningLanguageVersion]);
    if (!(int)$check->fetchColumn()) {
        ensure_column($pdo, 'tests', 'listening_language', 'VARCHAR(10) NULL AFTER listening_audio_path');
        $insert = $pdo->prepare('INSERT INTO schema_migrations(version) VALUES(?)');
        $insert->execute([$listeningLanguageVersion]);
    }
}
