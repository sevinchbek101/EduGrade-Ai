<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')]);
    session_start();
}

$envFile = dirname(__DIR__) . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        if (getenv($key) === false) putenv($key . '=' . trim($value, "\"'"));
    }
}

function app_config(): array { static $c; return $c ??= require dirname(__DIR__) . '/config/config.php'; }
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/gemini.php';
require_once dirname(__DIR__) . '/database/migrate_ai.php';

function e(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path = ''): string { return app_config()['app_url'] . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path))); exit; }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void { if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', (string)$_POST['csrf'])) { http_response_code(419); exit('Sessiya eskirgan. Sahifani yangilang.'); } }
function user(): ?array { return $_SESSION['user'] ?? null; }
function require_auth(): void { if (!user()) redirect('login.php'); }
function flash(string $type, string $message): void { $_SESSION['flash'] = compact('type', 'message'); }
function take_flash(): ?array { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }
function post_string(string $key): string { return trim((string)($_POST[$key] ?? '')); }
function owned_test(int $id): ?array { $s=db()->prepare('SELECT * FROM tests WHERE id=? AND user_id=?'); $s->execute([$id, user()['id']]); return $s->fetch() ?: null; }
function is_support_admin(): bool {
    if (!user()) return false;
    $adminEmail = app_config()['support_admin_email'];
    return ($adminEmail !== '' && strtolower((string)(user()['email'] ?? '')) === $adminEmail) || (int)(user()['id'] ?? 0) === 1;
}

if (basename((string)($_SERVER['SCRIPT_FILENAME'] ?? '')) !== 'setup.php') {
    try {
        run_ai_migration(db());
        unset($_SESSION['schema_migration_error']);
    } catch (Throwable $migrationError) {
        $_SESSION['schema_migration_error'] = 'Database yangilanishi bajarilmadi: ' . $migrationError->getMessage();
    }
}

function render_header(string $title, bool $dashboard = false): void {
    $flash = take_flash(); $name = app_config()['app_name']; $migrationError = user() ? ($_SESSION['schema_migration_error'] ?? null) : null;
    ?><!doctype html><html lang="uz"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?> — <?=e($name)?></title><link rel="icon" type="image/png" href="<?=e(url('assets/images/favicon.png'))?>"><link rel="apple-touch-icon" href="<?=e(url('assets/images/logo-icon.png'))?>"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="<?=e(url('assets/css/app.css'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/edugrade.css'))?>"></head><body class="<?=$dashboard?'app-shell':''?>">
    <?php if ($dashboard): ?><button class="mobile-menu" data-menu>☰</button><aside class="sidebar"><a class="brand" href="<?=e(url('dashboard.php'))?>"><img src="<?=e(url('assets/images/logo-icon.png'))?>" alt=""><strong>EduGrade AI</strong></a><nav><a href="<?=e(url('dashboard.php'))?>">▦ Dashboard</a><a href="<?=e(url('create-test.php'))?>">＋ Test yaratish</a><a href="<?=e(url('ai-create-test.php'))?>">✦ AI bilan yaratish</a><a href="<?=e(url('dashboard.php#results'))?>">▤ Natijalar</a><a href="<?=e(url('api-test.php'))?>">✦ AI API tekshiruvi</a><?php if(is_support_admin()):?><a href="<?=e(url('support-admin.php'))?>">◉ Support murojaatlari</a><?php endif?></nav><div class="sidebar-bottom"><div class="user-chip"><b><?=e(user()['first_name']??'')?></b><small><?=is_support_admin()?'Administrator':'O‘qituvchi'?></small></div><a href="<?=e(url('logout.php'))?>">↪ Chiqish</a></div></aside><main class="main"><?php endif; ?>
    <?php if ($flash): ?><div class="toast <?=$flash['type']?>"><?=e($flash['message'])?></div><?php endif; ?>
    <?php if ($migrationError): ?><div class="toast danger migration-toast"><?=e($migrationError)?></div><?php endif;
}
function render_footer(bool $dashboard = false): void { if($dashboard) echo '</main>'; if(user()): ?><div class="support-widget" data-support-widget data-endpoint="<?=e(url('api/support-chat.php'))?>"><button class="support-launcher" type="button" data-support-toggle aria-label="Yordamchini ochish">✦<span>Yordam</span></button><section class="support-window" data-support-window hidden><header><div><i>✦</i><span><b>EduGrade yordamchisi</b><small><em></em> Onlayn</small></span></div><button type="button" data-support-close aria-label="Yopish">×</button></header><div class="support-messages" data-support-messages><div class="support-message bot">Salom! Saytdan foydalanishda qanday yordam beray?</div></div><form data-support-form><?=csrf_field()?><textarea name="message" rows="1" maxlength="1000" placeholder="Savolingizni yozing..." required></textarea><button type="submit" aria-label="Yuborish">➤</button></form><p class="support-privacy">AI yecha olmasa, murojaat adminga yuboriladi.</p></section></div><?php endif; ?><script src="<?=e(url('assets/js/app.js'))?>"></script></body></html><?php }
