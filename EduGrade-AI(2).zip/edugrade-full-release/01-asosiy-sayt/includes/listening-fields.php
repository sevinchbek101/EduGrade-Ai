<?php
declare(strict_types=1);

function render_listening_fields(array $test = []): void
{
    $text = (string)($test['listening_text'] ?? '');
    $path = (string)($test['listening_audio_path'] ?? '');
    $selectedLanguage = (string)($test['listening_language'] ?? 'en');
    if (!isset(gemini_tts_languages()[$selectedLanguage])) $selectedLanguage = 'en';
    ?>
    <section class="panel listening-builder"
        data-listening-draft-endpoint="<?=e(url('api/generate-listening-draft.php'))?>"
        data-listening-audio-endpoint="<?=e(url('api/generate-listening.php'))?>">
        <div class="listening-heading"><span>🎧</span><div><h2>Listening mashqi</h2><p>AI inglizcha matn va savollar tayyorlaydi. Matnni tahrirlang, so‘ng audio yarating.</p></div></div>
        <div class="listening-ai-box">
            <label>Mavzu yoki vaziyat<input type="text" data-listening-topic maxlength="1000" placeholder="Masalan: A2 daraja, airport check-in suhbati"></label>
            <div class="grid listening-controls"><label>Til<select name="listening_language" data-listening-language><?php foreach(gemini_tts_languages() as $code=>$name):?><option value="<?=e($code)?>" <?=$code===$selectedLanguage?'selected':''?>><?=e($name)?> — <?=e($code)?></option><?php endforeach?></select></label><label>Daraja<select data-listening-level><option>A1</option><option selected>A2</option><option>B1</option><option>B2</option></select></label><label>Savollar soni<input type="number" data-listening-count min="2" max="10" value="5"></label><button type="button" class="btn ghost" data-generate-listening-draft>✦ AI matn va savollar yaratsin</button></div>
            <small class="language-note">Ro‘yxatda faqat Gemini TTS rasmiy qo‘llaydigan tillar bor. Til audio matnidan ham avtomatik aniqlanadi.</small>
        </div>
        <label>Listening matni <small>(o‘quvchiga ko‘rsatilmaydi)</small><textarea name="listening_text" data-listening-text rows="7" maxlength="3000" placeholder="Tanlangan tildagi Listening matni..."><?=e($text)?></textarea></label>
        <input type="hidden" name="listening_audio_path" data-listening-path value="<?=e($path)?>">
        <div class="grid listening-controls"><label>Ovoz<select data-listening-voice><option>Zephyr</option><option>Puck</option><option>Charon</option><option>Kore</option><option>Leda</option><option>Aoede</option><option>Iapetus</option><option>Achird</option><option>Sulafat</option></select></label><label>Uslub<select data-listening-style><option>Neutral</option><option>Helpful</option><option>Friendly</option><option>Informative</option><option>Cheerful</option><option>Serious</option></select></label><label>Tezlik<select data-listening-pace><option>Slow</option><option selected>Natural</option><option>Fast</option></select></label><button type="button" class="btn primary" data-generate-listening>Audio yaratish</button></div>
        <div class="listening-preview" data-listening-preview <?=$path === '' ? 'hidden' : ''?>><audio controls preload="metadata" <?=$path !== '' ? 'src="'.e(url($path)).'"' : ''?>></audio><button type="button" class="btn ghost" data-remove-listening>Audioni olib tashlash</button></div>
        <div class="import-status" data-listening-status hidden></div>
    </section>
    <?php
}
