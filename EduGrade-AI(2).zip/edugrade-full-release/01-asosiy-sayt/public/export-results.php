<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require_auth();

$test = owned_test((int)($_GET['id'] ?? 0));
if (!$test) { http_response_code(404); exit('Test topilmadi.'); }
if (!class_exists('ZipArchive')) { http_response_code(500); exit('Excel fayli yaratish uchun PHP zip kengaytmasini yoqing.'); }

$search = trim((string)($_GET['q'] ?? ''));
$class = trim((string)($_GET['class'] ?? ''));
$sql = 'SELECT * FROM test_attempts WHERE test_id=? AND submitted_at IS NOT NULL';
$args = [$test['id']];
if ($search !== '') { $sql .= ' AND CONCAT(student_first_name," ",student_last_name) LIKE ?'; $args[] = '%' . $search . '%'; }
if ($class !== '') { $sql .= ' AND student_class=?'; $args[] = $class; }
$sql .= ' ORDER BY submitted_at DESC';
$statement = db()->prepare($sql);$statement->execute($args);$rows = $statement->fetchAll();

function export_bho(float $percentage): string { return $percentage >= 86 ? '5' : ($percentage >= 71 ? '4' : ($percentage >= 56 ? '3' : '2')); }
function xml_value(string $value): string
{
    $value = preg_replace('/[^\x09\x0A\x0D\x20-\x{D7FF}\x{E000}-\x{FFFD}]/u', '', $value) ?? '';
    return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}
function string_cell(string $reference, string $value, int $style = 0): string
{
    return '<c r="'.$reference.'" t="inlineStr"'.($style ? ' s="'.$style.'"' : '').'><is><t xml:space="preserve">'.xml_value($value).'</t></is></c>';
}
function number_cell(string $reference, float|int $value, int $style = 0): string
{
    return '<c r="'.$reference.'"'.($style ? ' s="'.$style.'"' : '').'><v>'.(float)$value.'</v></c>';
}

$sheetRows = [];$rowNumber = 1;
$sheetRows[] = '<row r="1" ht="28" customHeight="1">'.string_cell('A1', (string)$test['title'].' — test natijalari', 1).'</row>';
$rowNumber++;
$average = count($rows) ? array_sum(array_map(static fn($row)=>(float)$row['percentage'], $rows)) / count($rows) : 0;
$sheetRows[] = '<row r="2">'.string_cell('A2', 'Topshirishlar: '.count($rows)).string_cell('C2', 'O‘rtacha: '.number_format($average, 1).'%').string_cell('E2', 'Yaratilgan: '.date('d.m.Y H:i')).'</row>';
$rowNumber = 4;
$headers = ['№','Ism','Familiya','Sinf','Ball','Maksimal ball','Foiz','BHO','AI holati','Topshirilgan vaqt'];
$headerCells = '';
foreach ($headers as $index=>$header) $headerCells .= string_cell(chr(65+$index).$rowNumber, $header, 2);
$sheetRows[] = '<row r="'.$rowNumber.'">'.$headerCells.'</row>';
foreach ($rows as $index=>$row) {
    $rowNumber++;$percent = (float)$row['percentage'];
    $cells = number_cell('A'.$rowNumber, $index+1)
        .string_cell('B'.$rowNumber, (string)$row['student_first_name'])
        .string_cell('C'.$rowNumber, (string)$row['student_last_name'])
        .string_cell('D'.$rowNumber, (string)$row['student_class'])
        .number_cell('E'.$rowNumber, (float)$row['score'], 3)
        .number_cell('F'.$rowNumber, (float)$row['max_score'], 3)
        .number_cell('G'.$rowNumber, $percent / 100, 4)
        .string_cell('H'.$rowNumber, export_bho($percent), 5)
        .string_cell('I'.$rowNumber, $row['ai_review_pending'] ? 'O‘qituvchi tekshiruvi kutilmoqda' : 'Tayyor')
        .string_cell('J'.$rowNumber, date('d.m.Y H:i', strtotime((string)$row['submitted_at'])));
    $sheetRows[] = '<row r="'.$rowNumber.'">'.$cells.'</row>';
}

$sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    .'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
    .'<cols><col min="1" max="1" width="6" customWidth="1"/><col min="2" max="3" width="20" customWidth="1"/><col min="4" max="4" width="13" customWidth="1"/><col min="5" max="8" width="14" customWidth="1"/><col min="9" max="9" width="31" customWidth="1"/><col min="10" max="10" width="20" customWidth="1"/></cols>'
    .'<sheetData>'.implode('', $sheetRows).'</sheetData><autoFilter ref="A4:J'.$rowNumber.'"/></worksheet>';
$workbookXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Natijalar" sheetId="1" r:id="rId1"/></sheets></workbook>';
$stylesXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="16"/><color rgb="FF123E70"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1762C4"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center"/></xf><xf numFmtId="2" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="10" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center"/></xf></cellXfs></styleSheet>';
$contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>';
$rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
$workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';

$temporary = tempnam(sys_get_temp_dir(), 'edugrade-results-');
if ($temporary === false) { http_response_code(500); exit('Vaqtinchalik Excel fayli yaratilmadi.'); }
$zip = new ZipArchive();
if ($zip->open($temporary, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { @unlink($temporary);http_response_code(500);exit('Excel fayli yaratilmadi.'); }
$zip->addFromString('[Content_Types].xml', $contentTypes);$zip->addFromString('_rels/.rels', $rootRels);$zip->addFromString('xl/workbook.xml', $workbookXml);$zip->addFromString('xl/_rels/workbook.xml.rels', $workbookRels);$zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);$zip->addFromString('xl/styles.xml', $stylesXml);$zip->close();

$safeTitle = preg_replace('/[^\pL\pN_-]+/u', '-', (string)$test['title']) ?: 'test';
$safeTitle = trim($safeTitle, '-');
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="'.rawurlencode($safeTitle.'-natijalar-'.date('Y-m-d').'.xlsx').'"');
header('Content-Length: '.filesize($temporary));
header('X-Content-Type-Options: nosniff');
readfile($temporary);@unlink($temporary);exit;
