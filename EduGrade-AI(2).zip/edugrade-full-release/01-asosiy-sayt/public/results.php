<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require_auth();
$test = owned_test((int)($_GET['id'] ?? 0));
if (!$test) { http_response_code(404); exit('Test topilmadi.'); }
$search = trim((string)($_GET['q'] ?? ''));
$class = trim((string)($_GET['class'] ?? ''));
$sql = 'SELECT * FROM test_attempts WHERE test_id=? AND submitted_at IS NOT NULL';
$args = [$test['id']];
if ($search !== '') { $sql .= ' AND CONCAT(student_first_name," ",student_last_name) LIKE ?'; $args[] = '%' . $search . '%'; }
if ($class !== '') { $sql .= ' AND student_class=?'; $args[] = $class; }
$sql .= ' ORDER BY submitted_at DESC';
$statement = db()->prepare($sql); $statement->execute($args); $rows = $statement->fetchAll();
$classesStatement = db()->prepare('SELECT DISTINCT student_class FROM test_attempts WHERE test_id=? ORDER BY student_class');
$classesStatement->execute([$test['id']]); $classes = $classesStatement->fetchAll(PDO::FETCH_COLUMN);
function bho(float $percentage): string { return $percentage >= 86 ? '5' : ($percentage >= 71 ? '4' : ($percentage >= 56 ? '3' : '2')); }
function bar_color(int $index): string { $colors=['#1769e0','#03a9b7','#6d5ce7','#14a56f','#f59e0b','#e84d67']; return $colors[$index % count($colors)]; }
$average = count($rows) ? array_sum(array_column($rows, 'percentage')) / count($rows) : 0;
$highest = count($rows) ? max(array_column($rows, 'percentage')) : 0;
$exportQuery = http_build_query(['id'=>$test['id'],'q'=>$search,'class'=>$class]);
render_header('Natijalar', true);
?>
<div class="topbar results-heading"><div><a href="<?=e(url('dashboard.php'))?>">← Dashboard</a><h1><?=e($test['title'])?></h1><p>O‘quvchilar natijalari va o‘zlashtirish diagrammasi</p></div><a class="btn excel-button" href="<?=e(url('export-results.php?'.$exportQuery))?>">▦ Excel yuklab olish</a></div>
<section class="stat-grid three"><div class="stat"><i class="blue">#</i><span>Topshirishlar<b><?=count($rows)?></b></span></div><div class="stat"><i class="green">%</i><span>O‘rtacha natija<b><?=number_format($average,1)?>%</b></span></div><div class="stat"><i class="orange">★</i><span>Eng yuqori<b><?=number_format((float)$highest,1)?>%</b></span></div></section>
<section class="results-split">
 <div class="panel results-table-panel"><div class="section-title"><div><h2>O‘quvchilar natijalari</h2><p>Ball, foiz va BHO baholari</p></div><span><?=count($rows)?> o‘quvchi</span></div>
  <form class="filters results-filters"><input name="id" type="hidden" value="<?=$test['id']?>"><input name="q" value="<?=e($search)?>" placeholder="O‘quvchi qidirish..."><select name="class"><option value="">Barcha sinflar</option><?php foreach($classes as $item):?><option value="<?=e($item)?>" <?=$class===$item?'selected':''?>><?=e($item)?></option><?php endforeach?></select><button class="btn primary small">Qidirish</button></form>
  <div class="table-wrap"><table class="results-table"><thead><tr><th>O‘quvchi</th><th>Sinf</th><th>Ball</th><th>Foiz</th><th>BHO</th></tr></thead><tbody><?php foreach($rows as $row):$percent=(float)$row['percentage'];?><tr><td><a href="<?=e(url('attempt-detail.php?id='.$row['id']))?>"><b><?=e($row['student_first_name'].' '.$row['student_last_name'])?></b></a><small><?=date('d.m.Y H:i',strtotime($row['submitted_at']))?><?php if($row['ai_review_pending']):?> · ⚠ AI tekshiruv kutilmoqda<?php endif?></small></td><td><?=e($row['student_class'])?></td><td><b><?=e($row['score'])?></b><small>/ <?=e($row['max_score'])?></small></td><td><span class="score-badge score-<?=bho($percent)?>"><?=number_format($percent,1)?>%</span></td><td><span class="grade grade-<?=bho($percent)?>"><?=bho($percent)?></span></td></tr><?php endforeach?><?php if(!$rows):?><tr><td colspan="5" class="empty-row">Natijalar topilmadi.</td></tr><?php endif?></tbody></table></div>
 </div>
 <div class="panel chart-panel"><div class="section-title"><div><h2>O‘zlashtirish diagrammasi</h2><p>O‘quvchilarning foiz ko‘rsatkichlari</p></div><span class="chart-legend"><i></i> Natija</span></div>
 <?php if($rows):?><div class="bar-chart" aria-label="O‘quvchilar natijalari ustunli diagrammasi"><div class="chart-y"><span>100%</span><span>75%</span><span>50%</span><span>25%</span><span>0%</span></div><div class="chart-plot"><div class="grid-line" style="bottom:25%"></div><div class="grid-line" style="bottom:50%"></div><div class="grid-line" style="bottom:75%"></div><div class="grid-line" style="bottom:100%"></div><div class="bars"><?php foreach($rows as $index=>$row):$percent=min(100,max(0,(float)$row['percentage']));?><div class="bar-item" title="<?=e($row['student_first_name'].' '.$row['student_last_name'])?> — <?=number_format($percent,1)?>%"><div class="bar-value"><?=number_format($percent,0)?>%</div><div class="bar" style="height:<?=$percent?>%;background:<?=bar_color($index)?>"></div><div class="bar-label"><?=e($row['student_first_name'])?><small><?=e($row['student_class'])?></small></div></div><?php endforeach?></div></div></div><div class="chart-summary"><span><i class="green-dot"></i>A’lo</span><span><i class="blue-dot"></i>Yaxshi</span><span><i class="orange-dot"></i>Qoniqarli</span><span><i class="red-dot"></i>Past</span></div><?php else:?><div class="chart-empty"><span>▥</span><h3>Diagramma uchun ma’lumot yo‘q</h3><p>O‘quvchilar test topshirgach, natijalar shu yerda ko‘rinadi.</p></div><?php endif?>
 </div>
</section>
<?php render_footer(true); ?>
