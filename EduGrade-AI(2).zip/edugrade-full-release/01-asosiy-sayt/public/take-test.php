<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
$token = (string)($_GET['attempt'] ?? '');
$statement = db()->prepare("SELECT a.*,t.title,t.description,t.listening_audio_path FROM test_attempts a JOIN tests t ON t.id=a.test_id WHERE a.attempt_token=? AND a.submitted_at IS NULL AND t.status='published'");
$statement->execute([$token]);
$attempt = $statement->fetch();
if (!$attempt) { http_response_code(404); exit('Urinish topilmadi yoki allaqachon topshirilgan.'); }
$query = db()->prepare('SELECT q.*,o.id option_id,o.option_text,o.option_key FROM questions q LEFT JOIN options o ON o.question_id=q.id WHERE q.test_id=? ORDER BY q.sort_order,o.sort_order');
$query->execute([$attempt['test_id']]);
$questions = [];
foreach ($query as $row) {
    $id = (int)$row['id'];
    if (!isset($questions[$id])) $questions[$id] = ['id'=>$id,'text'=>$row['question_text'],'type'=>$row['question_type'],'points'=>$row['points'],'image_path'=>$row['image_path']??null,'options'=>[]];
    if ($row['option_id']) $questions[$id]['options'][] = ['id'=>(int)$row['option_id'],'text'=>$row['option_text'],'key'=>$row['option_key']];
}
render_header($attempt['title']);
?>
<link rel="stylesheet" href="<?=e(url('assets/css/ai-import.css'))?>">
<header class="test-header"><div><span class="brand"><img src="<?=e(url('assets/images/logo-icon.png'))?>" alt=""><strong>EduGrade AI</strong></span><h2><?=e($attempt['title'])?></h2></div><div class="progress-info"><span>Javob berildi: <b data-answered>0</b> / <?=count($questions)?></span><div class="progress"><i data-progress></i></div></div></header>
<main class="test-page"><form id="student-test" method="post" action="<?=e(url('api/submit-test.php'))?>"><?=csrf_field()?><input type="hidden" name="attempt_token" value="<?=e($token)?>">
<?php if(!empty($attempt['listening_audio_path'])):?><section class="listening-player student-listening"><div><span>🎧</span><div><strong>Listening audio</strong><small>Avval audioni diqqat bilan tinglang, keyin savollarga javob bering.</small></div></div><audio controls preload="metadata" src="<?=e(url($attempt['listening_audio_path']))?>">Brauzeringiz audio pleerni qo‘llamaydi.</audio></section><?php endif?>
<?php $number=0; foreach($questions as $question): $number++; ?>
<article class="student-question <?=$question['type']==='written'?'written-question':''?>" data-student-question="<?=$question['id']?>"><div class="question-index"><?=$number?></div><div class="question-content"><div class="question-title"><h3><?=e($question['text'])?></h3><span><?=e($question['points'])?> ball</span></div>
<?php if(!empty($question['image_path'])):?><img class="student-question-image" src="<?=e(url($question['image_path']))?>" alt="Savolga tegishli rasm" loading="lazy"><?php endif?>
<?php if($question['type']==='written'):?>
    <div class="written-answer"><textarea name="written_answers[<?=$question['id']?>]" rows="6" maxlength="5000" placeholder="Javobingizni shu yerga yozing..." data-written-answer></textarea><div><span>✦ AI mazmun bo‘yicha baholaydi</span><small data-char-count>0 / 5000</small></div></div>
<?php else:?><div class="answer-list"><?php foreach($question['options'] as $option):$multiple=$question['type']==='multiple';?><label class="answer-option"><input type="<?=$multiple?'checkbox':'radio'?>" name="answers[<?=$question['id']?>]<?=$multiple?'[]':''?>" value="<?=$option['id']?>"><i><?=e($option['key'])?></i><span><?=e($option['text'])?></span><b>✓</b></label><?php endforeach?></div><?php if($question['type']==='multiple'):?><small class="hint">Bir nechta javob tanlash mumkin.</small><?php endif?><?php endif?>
</div></article>
<?php endforeach?>
<nav class="test-pagination" data-pagination><button class="btn ghost" type="button" data-prev>← Oldingi</button><span><b data-page-current>1</b> / <b data-page-total>1</b> sahifa<small>Har sahifada 5 ta savol</small></span><button class="btn primary" type="button" data-next>Keyingi →</button><button class="btn primary submit-test" data-submit>Testni yakunlash</button></nav>
</form></main>
<dialog id="submit-dialog"><div class="modal"><h2>Testni yakunlaysizmi?</h2><p data-dialog-text>Barcha javoblar saqlanadi va natijangiz hisoblanadi.</p><div><button class="btn ghost" type="button" data-close>Testga qaytish</button><button class="btn primary" type="button" data-confirm-submit>Topshirish</button></div></div></dialog>
<dialog id="grading-dialog"><div class="modal grading-modal"><div class="ai-loader">✦</div><h2>AI yozma javoblarni baholamoqda</h2><p>Iltimos, sahifani yopmang. Bu bir necha soniya davom etishi mumkin.</p></div></dialog>
<script src="<?=e(url('assets/js/student-test.js'))?>"></script><?php render_footer(); ?>
