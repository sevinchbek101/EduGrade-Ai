<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require_auth();
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') { verify_csrf(); $result = test_gemini_connection(); }
$config = app_config()['gemini'];
$relay = !empty($config['relay_url']);
$configError = gemini_config_error($config);
$checks = [
    ['name'=>$relay?'Vositachi / maxfiy token':'.env / API kalit','ok'=>$configError === '','detail'=>$configError !== ''?$configError:($relay?'Token sozlangan; Google kaliti ikkinchi hostingda':'Kalit topildi (yashirilgan)')],
    ['name'=>'PHP cURL','ok'=>function_exists('curl_init'),'detail'=>function_exists('curl_init')?'cURL yoqilgan':'cURL yoqilmagan'],
    ['name'=>'Model','ok'=>$config['model'] !== '','detail'=>$config['model']],
    ['name'=>$relay?'Vositachi manzili':'Gemini endpoint','ok'=>$configError === '','detail'=>$relay?($configError === ''?$config['relay_url']:'Relay sozlamalarini tekshiring'):'https://generativelanguage.googleapis.com/v1beta/interactions'],
];
render_header('AI API tekshiruvi', true);
?>
<div class="topbar"><div><a href="<?=e(url('dashboard.php'))?>">← Dashboard</a><h1>AI API tekshiruvi</h1><p>Gemini ulanishi va sozlamalarini xavfsiz tekshiring.</p></div></div>
<section class="api-test-layout"><div class="panel api-check-card"><div class="section-title"><div><h2>Server tayyorligi</h2><p>API kalit ekranda ko‘rsatilmaydi</p></div></div><div class="api-check-list"><?php foreach($checks as $check):?><div><i class="<?=$check['ok']?'ok':'bad'?>"><?=$check['ok']?'✓':'!'?></i><span><b><?=e($check['name'])?></b><small><?=e($check['detail'])?></small></span></div><?php endforeach?></div><form method="post" class="api-test-action"><?=csrf_field()?><button class="btn primary full">Gemini API’ni tekshirish</button></form></div>
<div class="panel api-result-card"><div class="section-title"><div><h2>Tekshiruv natijasi</h2><p>Haqiqiy Gemini API so‘rovi</p></div></div><?php if($result):?><div class="api-result <?=$result['ok']?'success':'failure'?>"><div class="api-result-icon"><?=$result['ok']?'✓':'!'?></div><h2><?=$result['ok']?'API ishlayapti':'API ishlamadi'?></h2><p><?=e($result['message'])?></p><dl><div><dt>HTTP holati</dt><dd><?=$result['status']?:'—'?></dd></div><div><dt>Bosqich</dt><dd><?=e($result['stage'])?></dd></div><div><dt>Model</dt><dd><?=e($config['model'])?></dd></div><?php if(!empty($result['output'])):?><div><dt>Model javobi</dt><dd><?=e($result['output'])?></dd></div><?php endif?><?php if(!empty($result['request_id'])):?><div><dt>Request ID</dt><dd><?=e($result['request_id'])?></dd></div><?php endif?></dl></div><?php else:?><div class="api-result-empty"><span>✦</span><h3>Tekshirishga tayyor</h3><p>Tugmani bosganda server Gemini’ga kichik test so‘rovi yuboradi.</p></div><?php endif?></div></section>
<?php render_footer(true); ?>
