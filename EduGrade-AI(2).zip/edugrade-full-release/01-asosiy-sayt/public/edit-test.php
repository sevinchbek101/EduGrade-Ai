<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/listening-fields.php';
require_auth();
$test = owned_test((int)($_GET['id'] ?? 0));
if (!$test) { http_response_code(404); exit('Test topilmadi.'); }
$statement = db()->prepare('SELECT q.*,o.id option_id,o.option_text,o.option_key,o.is_correct,o.sort_order option_order FROM questions q LEFT JOIN options o ON o.question_id=q.id WHERE q.test_id=? ORDER BY q.sort_order,o.sort_order');
$statement->execute([$test['id']]);
$questions = [];
foreach ($statement as $row) {
    $questionId = (int)$row['id'];
    if (!isset($questions[$questionId])) $questions[$questionId] = [
        'id'=>$questionId, 'text'=>$row['question_text'], 'type'=>$row['question_type'],
        'points'=>(float)$row['points'], 'referenceAnswer'=>(string)($row['ai_reference_answer'] ?? ''),
        'rubric'=>(string)($row['ai_rubric'] ?? ''), 'imagePath'=>(string)($row['image_path'] ?? ''),
        'imageUrl'=>!empty($row['image_path']) ? url($row['image_path']) : '', 'options'=>[],
    ];
    if ($row['option_id']) $questions[$questionId]['options'][] = ['id'=>(int)$row['option_id'],'text'=>$row['option_text'],'correct'=>(bool)$row['is_correct']];
}
$initial = array_values($questions);
render_header('Testni tahrirlash', true);
?>
<link rel="stylesheet" href="<?=e(url('assets/css/ai-import.css'))?>">
<div class="builder-top"><div><a href="<?=e(url('dashboard.php'))?>">← Dashboard</a><h1><?=e($test['title'])?></h1><p>Test ma’lumotlarini tahrirlang.</p></div><div class="score-pill">Jami: <b data-total>0</b> / <b data-max-view><?=e($test['max_score'])?></b> ball</div></div>
<form id="test-builder" class="builder" action="<?=e(url('api/save-test.php'))?>" method="post"><?=csrf_field()?><input type="hidden" name="test_id" value="<?=$test['id']?>"><div class="panel test-meta"><div class="grid two"><label>Test nomi<input name="title" value="<?=e($test['title'])?>" required></label><label>Maksimal ball<input type="number" min="1" step="0.01" name="max_score" value="<?=e($test['max_score'])?>" required data-max></label></div><label>Tavsif<textarea name="description" rows="2"><?=e($test['description'])?></textarea></label></div><?php render_listening_fields($test);?><div data-questions></div><button type="button" class="add-question" data-add-question>＋ Yangi savol qo‘shish</button><div class="builder-actions"><button class="btn ghost" name="action" value="draft">Qoralama saqlash</button><button class="btn primary" name="action" value="publish">Testni nashr qilish</button></div></form>
<template id="question-template"><article class="question-card" data-question><div class="q-head"><div><span class="q-number">Savol</span><small data-question-title></small></div><button type="button" data-remove-question>🗑</button></div><label>Savol matni<textarea data-field="text" rows="2" required></textarea></label><div class="question-image-field"><label>Savol rasmi <small>(ixtiyoriy)</small><input type="file" data-question-image accept="image/jpeg,image/png,image/webp"></label><div class="question-image-preview" data-image-preview hidden><img alt="Savol rasmi"><button type="button" data-remove-image>Rasmni olib tashlash</button></div><p data-image-hint hidden>AI faylda rasmga bog‘liq savol topdi. Kerakli rasmni shu yerga yuklang.</p></div><div class="grid two"><label>Savol turi<select data-field="type"><option value="single">Bitta javob</option><option value="multiple">Bir nechta javob</option><option value="written">Yozma javob — AI baholaydi</option></select></label><label>Ball<input data-field="points" type="number" min="0.01" step="0.01" required></label></div><div class="options" data-options></div><button type="button" class="add-option" data-add-option>＋ Javob varianti</button><div class="written-fields" data-written-fields hidden><div class="ai-notice">✦ AI javobni so‘zma-so‘z emas, mazmun va mezon asosida baholaydi.</div><label>Namunaviy javob<textarea data-field="reference" rows="3" maxlength="5000"></textarea></label><label>Baholash mezoni<textarea data-field="rubric" rows="3" maxlength="5000"></textarea></label></div></article></template>
<script>window.INITIAL_QUESTIONS=<?=json_encode($initial,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;</script>
<script src="<?=e(url('assets/js/test-builder.js'))?>"></script>
<?php render_footer(true); ?>
