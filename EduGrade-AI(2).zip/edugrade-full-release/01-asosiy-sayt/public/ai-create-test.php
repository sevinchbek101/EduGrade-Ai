<?php declare(strict_types=1);require dirname(__DIR__).'/includes/bootstrap.php';require_auth();render_header('AI yordamida test yaratish',true);?>
<link rel="stylesheet" href="<?=e(url('assets/css/ai-test-generator.css'))?>">
<div class="ai-generator-page">
  <header class="ai-generator-head"><a href="<?=e(url('dashboard.php'))?>">← Dashboard</a><span>EDUGRADE AI</span><h1>AI yordamida yangi test yarating</h1><p>Mavzu va talablarni yozing. Gemini savollarni tayyorlaydi, siz esa tahrirlab nashr qilasiz.</p></header>
  <form class="ai-generator-card" id="ai-test-generator" action="<?=e(url('api/generate-test.php'))?>" method="post" enctype="multipart/form-data">
    <?=csrf_field()?>
    <section class="prompt-box">
      <label for="ai-prompt">Test uchun topshiriq</label>
      <textarea id="ai-prompt" name="prompt" rows="9" minlength="10" maxlength="5000" required placeholder="Masalan: 7-sinf biologiya fanidan fotosintez mavzusida, asosiy tushunchalar va hayotiy misollarni tekshiradigan test yarating..."></textarea>
      <div class="prompt-tools"><label class="image-upload"><input type="file" name="context_image" accept="image/jpeg,image/png,image/webp"><span>▧ Rasm yuklash</span></label><small data-image-name>JPG, PNG yoki WEBP · 5 MB gacha</small></div>
    </section>
    <div class="generator-grid">
      <label class="generator-control type-control"><span>Test turi</span><select name="test_type"><option value="single">Test — bitta to‘g‘ri javob</option><option value="written">Yozma savollar</option><option value="multiple">Bir nechta to‘g‘ri javobli test</option><option value="mixed">Barchasi — aralash</option></select></label>
      <label class="generator-control score-control"><span>Maksimal ball</span><input type="number" name="max_score" min="1" max="1000" step="0.01" value="25" required></label>
      <label class="generator-control points-control"><span>Ballarni taqsimlash</span><select name="scoring_mode"><option value="ai">AI qiyinligiga qarab taqsimlaydi</option><option value="manual">Ballarni o‘zim kiritaman</option></select></label>
      <label class="generator-control count-control"><span>Savollar soni</span><input type="number" name="question_count" min="1" max="50" value="10" required></label>
    </div>
    <div class="generator-note"><span>✦</span><p>AI yaratgan test avtomatik nashr qilinmaydi. Avval barcha savol, javob va ballarni tekshirib tahrirlaysiz.</p></div>
    <div class="generator-status" data-generator-status hidden></div>
    <button class="generate-button" type="submit">✦ Testni yaratish</button>
  </form>
</div>
<div class="ai-generating" data-generating hidden><div><span>✦</span><h2>AI testingizni yaratmoqda</h2><p>Savollar, javoblar va ballar tayyorlanmoqda. Iltimos, sahifani yopmang.</p></div></div>
<script src="<?=e(url('assets/js/ai-test-generator.js'))?>"></script>
<?php render_footer(true);?>
