<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
function listening_reply(int $status, array $payload): never { http_response_code($status); echo json_encode($payload, JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') listening_reply(405, ['ok'=>false,'message'=>'Faqat POST so‘rovi.']);
if (!user()) listening_reply(401, ['ok'=>false,'message'=>'Qayta tizimga kiring.']);
try { verify_csrf(); } catch (Throwable $e) { listening_reply(419, ['ok'=>false,'message'=>'Sessiya eskirgan. Sahifani yangilang.']); }
$text = trim((string)($_POST['text'] ?? ''));
try {
    $wav = generate_listening_audio($text, (string)($_POST['language'] ?? 'en'), (string)($_POST['voice'] ?? 'Zephyr'), (string)($_POST['style'] ?? 'Neutral'), (string)($_POST['pace'] ?? 'Natural'));
    $directory = dirname(__DIR__) . '/assets/uploads/listening';
    if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) throw new RuntimeException('Audio papkasini yaratib bo‘lmadi.');
    $name = bin2hex(random_bytes(20)) . '.wav';
    if (file_put_contents($directory . '/' . $name, $wav, LOCK_EX) !== strlen($wav)) throw new RuntimeException('Audio faylni saqlab bo‘lmadi.');
    listening_reply(200, ['ok'=>true,'audio_path'=>'assets/uploads/listening/'.$name,'audio_url'=>url('assets/uploads/listening/'.$name)]);
} catch (Throwable $e) {
    listening_reply(502, ['ok'=>false,'message'=>$e->getMessage()]);
}
