<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('');
verify_csrf();
$token = (string)($_POST['attempt_token'] ?? '');
$pdo = db();

$attemptQuery = $pdo->prepare("SELECT a.*,t.status FROM test_attempts a JOIN tests t ON t.id=a.test_id WHERE a.attempt_token=? AND a.submitted_at IS NULL AND t.status='published'");
$attemptQuery->execute([$token]);
$attempt = $attemptQuery->fetch();
if (!$attempt) { http_response_code(422); exit('Urinish yaroqsiz yoki allaqachon topshirilgan.'); }

$questionQuery = $pdo->prepare('SELECT q.*,o.id option_id,o.is_correct FROM questions q LEFT JOIN options o ON o.question_id=q.id WHERE q.test_id=? ORDER BY q.id,o.id');
$questionQuery->execute([$attempt['test_id']]);
$questions = [];
foreach ($questionQuery as $row) {
    $questionId = (int)$row['id'];
    if (!isset($questions[$questionId])) $questions[$questionId] = [
        'id'=>$questionId, 'question_text'=>$row['question_text'], 'question_type'=>$row['question_type'],
        'points'=>(float)$row['points'], 'ai_reference_answer'=>$row['ai_reference_answer'], 'ai_rubric'=>$row['ai_rubric'],
        'valid'=>[], 'correct'=>[],
    ];
    if ($row['option_id']) {
        $questions[$questionId]['valid'][] = (int)$row['option_id'];
        if ($row['is_correct']) $questions[$questionId]['correct'][] = (int)$row['option_id'];
    }
}

$objectiveAnswers = $_POST['answers'] ?? [];
$writtenAnswers = $_POST['written_answers'] ?? [];
$preparedAnswers = [];
$score = 0.0;
$reviewPending = false;

foreach ($questions as $questionId => $question) {
    if ($question['question_type'] === 'written') {
        $answerText = trim((string)($writtenAnswers[$questionId] ?? ''));
        if ($answerText === '') continue;
        if (strlen($answerText) > 20000) { http_response_code(422); exit('Yozma javob juda uzun.'); }
        $grade = grade_written_answer($question, $answerText);
        $score += (float)$grade['score'];
        $reviewPending = $reviewPending || (bool)$grade['needs_review'];
        $preparedAnswers[] = ['kind'=>'written','question_id'=>$questionId,'text'=>$answerText,'grade'=>$grade];
        continue;
    }
    $selected = $objectiveAnswers[$questionId] ?? [];
    if (!is_array($selected)) $selected = [$selected];
    $selected = array_values(array_unique(array_map('intval', $selected)));
    foreach ($selected as $optionId) {
        if (!in_array($optionId, $question['valid'], true)) { http_response_code(422); exit('Noto‘g‘ri javob varianti.'); }
        $preparedAnswers[] = ['kind'=>'option','question_id'=>$questionId,'option_id'=>$optionId];
    }
    $correct = $question['correct']; sort($selected); sort($correct);
    if ($selected === $correct) $score += $question['points'];
}

$percentage = (float)$attempt['max_score'] > 0 ? round($score / (float)$attempt['max_score'] * 100, 2) : 0;
try {
    $pdo->beginTransaction();
    $lock = $pdo->prepare('SELECT id FROM test_attempts WHERE id=? AND submitted_at IS NULL FOR UPDATE');
    $lock->execute([$attempt['id']]);
    if (!$lock->fetchColumn()) throw new RuntimeException('Bu test allaqachon topshirilgan.');
    $insertOption = $pdo->prepare('INSERT INTO student_answers(attempt_id,question_id,option_id) VALUES(?,?,?)');
    $insertWritten = $pdo->prepare('INSERT INTO student_answers(attempt_id,question_id,option_id,answer_text,ai_score,ai_feedback,ai_confidence,requires_review,ai_model) VALUES(?,?,NULL,?,?,?,?,?,?)');
    foreach ($preparedAnswers as $answer) {
        if ($answer['kind'] === 'option') $insertOption->execute([$attempt['id'], $answer['question_id'], $answer['option_id']]);
        else {
            $grade = $answer['grade'];
            $insertWritten->execute([$attempt['id'], $answer['question_id'], $answer['text'], $grade['score'], $grade['feedback'], $grade['confidence'], $grade['needs_review'] ? 1 : 0, $grade['model']]);
        }
    }
    $update = $pdo->prepare('UPDATE test_attempts SET score=?,percentage=?,ai_review_pending=?,submitted_at=NOW() WHERE id=? AND submitted_at IS NULL');
    $update->execute([$score, $percentage, $reviewPending ? 1 : 0, $attempt['id']]);
    $pdo->commit();
    redirect('result.php?attempt=' . $token);
} catch (Throwable $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(422); exit(e($error->getMessage()));
}
