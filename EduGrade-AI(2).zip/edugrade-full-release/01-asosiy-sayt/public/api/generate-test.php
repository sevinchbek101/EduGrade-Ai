<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_auth();
header('Content-Type: application/json; charset=utf-8');

function generation_reply(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') generation_reply(405, ['ok'=>false,'message'=>'Faqat POST so‘rovi qabul qilinadi.']);
try { verify_csrf(); }
catch (Throwable) { generation_reply(419, ['ok'=>false,'message'=>'Sessiya eskirgan. Sahifani yangilang.']); }

$prompt = trim((string)($_POST['prompt'] ?? ''));
$length = function_exists('mb_strlen') ? mb_strlen($prompt) : strlen($prompt);
if ($length < 10 || $length > 5000) generation_reply(422, ['ok'=>false,'message'=>'Topshiriq 10–5000 belgi oralig‘ida bo‘lsin.']);
$testType = (string)($_POST['test_type'] ?? '');
$scoringMode = (string)($_POST['scoring_mode'] ?? '');
$maxScore = filter_var($_POST['max_score'] ?? null, FILTER_VALIDATE_FLOAT);
$questionCount = filter_var($_POST['question_count'] ?? null, FILTER_VALIDATE_INT);
if (!in_array($testType, ['single','multiple','written','mixed'], true)) generation_reply(422, ['ok'=>false,'message'=>'Test turi noto‘g‘ri tanlangan.']);
if (!in_array($scoringMode, ['ai','manual'], true)) generation_reply(422, ['ok'=>false,'message'=>'Ball taqsimoti noto‘g‘ri tanlangan.']);
if ($maxScore === false || $maxScore < 1 || $maxScore > 1000) generation_reply(422, ['ok'=>false,'message'=>'Maksimal ball 1–1000 oralig‘ida bo‘lsin.']);
if ($questionCount === false || $questionCount < 1 || $questionCount > 50) generation_reply(422, ['ok'=>false,'message'=>'Savollar soni 1–50 oralig‘ida bo‘lsin.']);

$imageBytes = null;$imageMime = null;$file = $_FILES['context_image'] ?? null;
if (is_array($file) && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) generation_reply(422, ['ok'=>false,'message'=>'Rasm to‘liq yuklanmadi.']);
    if ((int)($file['size'] ?? 0) < 1 || (int)$file['size'] > 5 * 1024 * 1024) generation_reply(422, ['ok'=>false,'message'=>'Rasm hajmi 5 MB dan oshmasin.']);
    $tmp = (string)($file['tmp_name'] ?? '');
    $imageMime = function_exists('finfo_open') ? (new finfo(FILEINFO_MIME_TYPE))->file($tmp) : '';
    if (!in_array($imageMime, ['image/jpeg','image/png','image/webp'], true)) generation_reply(422, ['ok'=>false,'message'=>'Faqat JPG, PNG yoki WEBP rasm yuklang.']);
    $imageBytes = file_get_contents($tmp);
    if ($imageBytes === false) generation_reply(422, ['ok'=>false,'message'=>'Rasmni o‘qib bo‘lmadi.']);
}

try {
    $test = generate_test_draft(['prompt'=>$prompt,'test_type'=>$testType,'scoring_mode'=>$scoringMode,'max_score'=>(float)$maxScore,'question_count'=>(int)$questionCount], $imageBytes, $imageMime);
    generation_reply(200, ['ok'=>true,'test'=>$test]);
} catch (Throwable $error) {
    generation_reply(502, ['ok'=>false,'message'=>$error->getMessage()]);
}
