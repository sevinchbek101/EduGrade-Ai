<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
require_auth();
header('Content-Type: application/json; charset=utf-8');

function import_reply(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') import_reply(405, ['ok'=>false,'message'=>'Faqat POST so‘rovi qabul qilinadi.']);
try { verify_csrf(); }
catch (Throwable) { import_reply(419, ['ok'=>false,'message'=>'Sessiya eskirgan. Sahifani yangilang.']); }

$file = $_FILES['source_file'] ?? null;
if (!$file || !is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) import_reply(422, ['ok'=>false,'message'=>'Fayl to‘liq yuklanmadi.']);
$size = (int)($file['size'] ?? 0);
if ($size < 1 || $size > 15 * 1024 * 1024) import_reply(422, ['ok'=>false,'message'=>'Fayl hajmi 15 MB dan oshmasin.']);
$tmp = (string)($file['tmp_name'] ?? '');
$name = basename((string)($file['name'] ?? 'hujjat'));
$extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
$detected = function_exists('finfo_open') ? (new finfo(FILEINFO_MIME_TYPE))->file($tmp) : '';
$allowed = ['application/pdf','image/jpeg','image/png','image/webp','text/plain'];
$bytes = (string)file_get_contents($tmp);

if ($extension === 'docx') {
    if (!class_exists('ZipArchive')) import_reply(422, ['ok'=>false,'message'=>'DOCX o‘qish uchun PHP zip kengaytmasini yoqing yoki faylni PDF qilib yuklang.']);
    $zip = new ZipArchive();
    if ($zip->open($tmp) !== true) import_reply(422, ['ok'=>false,'message'=>'DOCX faylini ochib bo‘lmadi.']);
    $xml = (string)$zip->getFromName('word/document.xml');
    $zip->close();
    if ($xml === '') import_reply(422, ['ok'=>false,'message'=>'DOCX ichida o‘qiladigan matn topilmadi.']);
    $xml = str_replace(['</w:p>','</w:tr>','<w:tab/>'], ["\n","\n","\t"], $xml);
    $bytes = html_entity_decode(strip_tags($xml), ENT_QUOTES | ENT_XML1, 'UTF-8');
    if (strlen($bytes) > 500000) import_reply(422, ['ok'=>false,'message'=>'DOCX matni juda katta. 500 000 belgidan kichik hujjat yuklang.']);
    $detected = 'text/plain';
} elseif (!in_array($detected, $allowed, true)) {
    import_reply(422, ['ok'=>false,'message'=>'PDF, DOCX, TXT, JPG, PNG yoki WEBP fayl yuklang.']);
}
if ($detected === 'text/plain' && strlen($bytes) > 500000) import_reply(422, ['ok'=>false,'message'=>'Matnli fayl 500 000 belgidan oshmasin.']);

try {
    $result = import_test_from_file($bytes, $detected, $name);
    import_reply(200, ['ok'=>true,'test'=>$result]);
} catch (Throwable $error) {
    import_reply(502, ['ok'=>false,'message'=>$error->getMessage()]);
}
