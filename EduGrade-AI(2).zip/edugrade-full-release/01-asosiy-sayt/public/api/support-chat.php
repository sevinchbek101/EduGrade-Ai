<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';require_auth();
header('Content-Type: application/json; charset=utf-8');
function support_reply(int $status, array $data): never { http_response_code($status);echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') support_reply(405, ['ok'=>false,'message'=>'Faqat POST so‘rovi qabul qilinadi.']);
if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', (string)$_POST['csrf'])) support_reply(419, ['ok'=>false,'message'=>'Sessiya eskirgan. Sahifani yangilang.']);
$message = trim((string)($_POST['message'] ?? ''));$length = function_exists('mb_strlen')?mb_strlen($message):strlen($message);
if ($length < 2 || $length > 1000) support_reply(422, ['ok'=>false,'message'=>'Xabar 2–1000 belgi oralig‘ida bo‘lsin.']);
if (isset($_SESSION['support_last_request']) && microtime(true)-(float)$_SESSION['support_last_request']<1.5) support_reply(429, ['ok'=>false,'message'=>'Iltimos, bir oz kutib qayta yuboring.']);
$_SESSION['support_last_request']=microtime(true);$history=is_array($_SESSION['support_history']??null)?$_SESSION['support_history']:[];
$result=support_chat_response($message,$history);$history[]=['role'=>'user','content'=>$message];$history[]=['role'=>'assistant','content'=>$result['reply']];$history=array_slice($history,-10);$_SESSION['support_history']=$history;
$ticketId=null;
if ($result['needs_admin']) {
    $summary=trim((string)$result['ticket_summary']);if($summary==='')$summary=$message;
    $summary=function_exists('mb_substr')?mb_substr($summary,0,255):substr($summary,0,255);
    $conversation=json_encode($history,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $activeId=(int)($_SESSION['support_ticket_id']??0);$active=null;
    if($activeId){$check=db()->prepare("SELECT id FROM support_tickets WHERE id=? AND user_id=? AND status='open'");$check->execute([$activeId,user()['id']]);$active=$check->fetch();}
    if($active){$statement=db()->prepare('UPDATE support_tickets SET subject=?,last_message=?,conversation_json=? WHERE id=? AND user_id=?');$statement->execute([$summary,$message,$conversation,$activeId,user()['id']]);$ticketId=$activeId;}
    else{$statement=db()->prepare('INSERT INTO support_tickets(user_id,subject,last_message,conversation_json) VALUES(?,?,?,?)');$statement->execute([user()['id'],$summary,$message,$conversation]);$ticketId=(int)db()->lastInsertId();$_SESSION['support_ticket_id']=$ticketId;}
}
support_reply(200,['ok'=>true,'reply'=>$result['reply'],'escalated'=>(bool)$result['needs_admin'],'ticket_id'=>$ticketId]);
