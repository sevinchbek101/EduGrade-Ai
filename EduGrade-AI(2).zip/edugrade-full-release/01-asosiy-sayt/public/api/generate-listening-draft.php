<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
function draft_reply(int $status, array $payload): never { http_response_code($status); echo json_encode($payload, JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') draft_reply(405, ['ok'=>false,'message'=>'Faqat POST so‘rovi.']);
if (!user()) draft_reply(401, ['ok'=>false,'message'=>'Qayta tizimga kiring.']);
try { verify_csrf(); } catch (Throwable $e) { draft_reply(419, ['ok'=>false,'message'=>'Sessiya eskirgan. Sahifani yangilang.']); }
try {
    $draft = generate_listening_draft((string)($_POST['topic'] ?? ''), (string)($_POST['language'] ?? 'en'), (string)($_POST['level'] ?? 'A2'), (int)($_POST['question_count'] ?? 5));
    draft_reply(200, ['ok'=>true,'draft'=>$draft]);
} catch (Throwable $e) {
    draft_reply(502, ['ok'=>false,'message'=>$e->getMessage()]);
}
