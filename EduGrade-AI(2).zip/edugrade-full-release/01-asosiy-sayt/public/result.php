<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
$statement = db()->prepare('SELECT a.*,t.title,(SELECT COUNT(DISTINCT question_id) FROM student_answers WHERE attempt_id=a.id) answered FROM test_attempts a JOIN tests t ON t.id=a.test_id WHERE a.attempt_token=? AND a.submitted_at IS NOT NULL');
$statement->execute([(string)($_GET['attempt'] ?? '')]);
$attempt = $statement->fetch();
if (!$attempt) { http_response_code(404); exit('Natija topilmadi.'); }
$totalQuery = db()->prepare('SELECT COUNT(*) FROM questions WHERE test_id=?');
$totalQuery->execute([$attempt['test_id']]);
$totalQuestions = (int)$totalQuery->fetchColumn();
$writtenQuery = db()->prepare("SELECT q.question_text,q.points,a.answer_text,a.ai_score,a.ai_feedback,a.ai_confidence,a.requires_review FROM student_answers a JOIN questions q ON q.id=a.question_id WHERE a.attempt_id=? AND q.question_type='written' ORDER BY q.sort_order");
$writtenQuery->execute([$attempt['id']]);
$writtenGrades = $writtenQuery->fetchAll();
render_header('Natija');
?>
<main class="result-page"><div class="result-card"><div class="result-icon">✓</div><span class="eyebrow">TEST YAKUNLANDI</span><h1><?=e($attempt['title'])?></h1>
<?php if($attempt['ai_review_pending']):?><div class="review-notice">⚠ Natija dastlabki hisoblandi. Ayrim yozma javoblar o‘qituvchi tekshiruvini kutmoqda.</div><?php endif?>
<div class="score-ring" style="--p:<?=min(100,(float)$attempt['percentage'])?>"><div><b><?=e($attempt['score'])?></b><small>/ <?=e($attempt['max_score'])?></small></div></div><h2><?=e($attempt['percentage'])?>%</h2><p class="result-message"><?=$attempt['percentage']>=86?'A’lo natija!':($attempt['percentage']>=70?'Yaxshi natija!':'Harakatni davom ettiring!')?></p>
<div class="result-details"><span>O‘quvchi<b><?=e($attempt['student_first_name'].' '.$attempt['student_last_name'])?></b></span><span>Sinf<b><?=e($attempt['student_class'])?></b></span><span>Javob berildi<b><?=$attempt['answered']?> / <?=$totalQuestions?></b></span><span>Topshirildi<b><?=date('d.m.Y H:i',strtotime($attempt['submitted_at']))?></b></span></div>
<?php if($writtenGrades):?><section class="ai-feedback-list"><h2>Yozma javoblar bo‘yicha AI izohi</h2><?php foreach($writtenGrades as $grade):?><article><div><h3><?=e($grade['question_text'])?></h3><span><?=e($grade['ai_score'])?> / <?=e($grade['points'])?> ball</span></div><p><b>Sizning javobingiz:</b> <?=nl2br(e($grade['answer_text']))?></p><p class="ai-feedback">✦ <?=e($grade['ai_feedback'])?></p><?php if($grade['requires_review']):?><small>O‘qituvchi tekshiruvi kerak</small><?php endif?></article><?php endforeach?></section><?php endif?>
</div></main><?php render_footer(); ?>
