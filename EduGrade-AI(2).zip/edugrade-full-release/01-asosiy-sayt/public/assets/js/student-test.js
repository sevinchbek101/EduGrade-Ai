(() => {
    const form = document.querySelector('#student-test');
    if (!form) return;

    const pageSize = 5;
    const cards = [...form.querySelectorAll('[data-student-question]')];
    const totalPages = Math.max(1, Math.ceil(cards.length / pageSize));
    const answered = document.querySelector('[data-answered]');
    const bar = document.querySelector('[data-progress]');
    const dialog = document.querySelector('#submit-dialog');
    const previousButton = form.querySelector('[data-prev]');
    const nextButton = form.querySelector('[data-next]');
    const submitButton = form.querySelector('[data-submit]');
    const currentPageLabel = form.querySelector('[data-page-current]');
    const totalPageLabel = form.querySelector('[data-page-total]');
    let currentPage = 1;

    totalPageLabel.textContent = totalPages;

    function updateProgress() {
        let count = 0;
        cards.forEach(card => {
            const written = card.querySelector('[data-written-answer]');
            const hasAnswer = written ? written.value.trim().length > 0 : !!card.querySelector('input:checked');
            card.classList.toggle('answered', hasAnswer);
            if (hasAnswer) count++;
        });
        answered.textContent = count;
        bar.style.width = `${cards.length ? count / cards.length * 100 : 0}%`;
        return count;
    }

    function showPage(page, scroll = true) {
        currentPage = Math.min(totalPages, Math.max(1, page));
        const start = (currentPage - 1) * pageSize;
        const end = start + pageSize;
        cards.forEach((card, index) => {
            card.hidden = index < start || index >= end;
        });
        currentPageLabel.textContent = currentPage;
        previousButton.hidden = currentPage === 1;
        nextButton.hidden = currentPage === totalPages;
        submitButton.hidden = currentPage !== totalPages;
        if (scroll) window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    previousButton.addEventListener('click', () => showPage(currentPage - 1));
    nextButton.addEventListener('click', () => showPage(currentPage + 1));
    form.addEventListener('change', updateProgress);
    form.querySelectorAll('[data-written-answer]').forEach(textarea => {
        const counter = textarea.closest('.written-answer').querySelector('[data-char-count]');
        textarea.addEventListener('input', () => {
            counter.textContent = `${textarea.value.length} / 5000`;
            updateProgress();
        });
    });
    form.addEventListener('submit', event => {
        event.preventDefault();
        const count = updateProgress();
        const missing = cards.length - count;
        dialog.querySelector('[data-dialog-text]').textContent = missing
            ? `Siz ${cards.length} ta savoldan ${count} tasiga javob berdingiz. ${missing} ta savol javobsiz. Baribir topshirasizmi?`
            : 'Barcha savollarga javob berdingiz. Natijani hisoblaymizmi?';
        dialog.showModal();
    });
    dialog.querySelector('[data-close]').addEventListener('click', () => dialog.close());
    dialog.querySelector('[data-confirm-submit]').addEventListener('click', () => {
        dialog.close();
        if (form.querySelector('[data-written-answer]')) document.querySelector('#grading-dialog').showModal();
        HTMLFormElement.prototype.submit.call(form);
    });

    updateProgress();
    showPage(1, false);
})();
