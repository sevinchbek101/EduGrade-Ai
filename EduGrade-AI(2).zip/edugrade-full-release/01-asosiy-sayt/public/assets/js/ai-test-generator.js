(() => {
 const form=document.querySelector('#ai-test-generator');if(!form)return;
 const file=form.querySelector('input[name=context_image]'),name=document.querySelector('[data-image-name]'),status=document.querySelector('[data-generator-status]'),overlay=document.querySelector('[data-generating]'),button=form.querySelector('button[type=submit]');
 file.addEventListener('change',()=>{const selected=file.files?.[0];name.textContent=selected?selected.name:'JPG, PNG yoki WEBP · 5 MB gacha'});
 form.addEventListener('submit',async event=>{event.preventDefault();status.hidden=true;const selected=file.files?.[0];if(selected&&selected.size>5*1024*1024){status.hidden=false;status.className='generator-status error';status.textContent='Rasm hajmi 5 MB dan oshmasin.';return}button.disabled=true;overlay.hidden=false;
  try{const response=await fetch(form.action,{method:'POST',body:new FormData(form)}),data=await response.json().catch(()=>({ok:false,message:'Server JSON javob qaytarmadi.'}));if(!response.ok||!data.ok)throw new Error(data.message||'Test yaratilmadi.');sessionStorage.setItem('edugrade_ai_test_draft',JSON.stringify(data.test));window.location.href='create-test.php?ai_draft=1'}
  catch(error){overlay.hidden=true;button.disabled=false;status.hidden=false;status.className='generator-status error';status.textContent=error.message||'Noma’lum xatolik yuz berdi.'}
 });
})();
