document.querySelector('[data-menu]')?.addEventListener('click',()=>document.querySelector('.sidebar')?.classList.toggle('open'));
document.querySelectorAll('[data-copy]').forEach(b=>b.addEventListener('click',async()=>{await navigator.clipboard.writeText(b.dataset.copy);const old=b.textContent;b.textContent='Nusxalandi ✓';setTimeout(()=>b.textContent=old,1600)}));
document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm(f.dataset.confirm))e.preventDefault()}));
setTimeout(()=>document.querySelector('.toast')?.remove(),4200);
(() => {
 const widget=document.querySelector('[data-support-widget]');if(!widget)return;
 const windowBox=widget.querySelector('[data-support-window]'),messages=widget.querySelector('[data-support-messages]'),form=widget.querySelector('[data-support-form]'),input=form.querySelector('textarea'),submit=form.querySelector('button[type=submit]');
 const toggle=open=>{windowBox.hidden=!open;if(open){setTimeout(()=>input.focus(),50);messages.scrollTop=messages.scrollHeight}};
 widget.querySelector('[data-support-toggle]').addEventListener('click',()=>toggle(windowBox.hidden));widget.querySelector('[data-support-close]').addEventListener('click',()=>toggle(false));
 const add=(text,type)=>{const item=document.createElement('div');item.className=`support-message ${type}`;item.textContent=text;messages.append(item);messages.scrollTop=messages.scrollHeight;return item};
 input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,110)+'px'});input.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();form.requestSubmit()}});
 form.addEventListener('submit',async event=>{event.preventDefault();const message=input.value.trim();if(!message)return;add(message,'user');input.value='';input.style.height='auto';submit.disabled=true;const typing=add('Yozmoqda…','bot typing');try{const body=new FormData(form);body.set('message',message);const response=await fetch(widget.dataset.endpoint,{method:'POST',body}),data=await response.json().catch(()=>({ok:false,message:'Server javobi olinmadi.'}));typing.remove();if(!response.ok||!data.ok)throw new Error(data.message||'Xabar yuborilmadi.');add(data.reply,'bot');if(data.escalated)add(`Murojaat raqami: #${data.ticket_id}`,'system')}catch(error){typing.remove();add(error.message||'Xatolik yuz berdi.','system')}finally{submit.disabled=false;input.focus()}});
})();
