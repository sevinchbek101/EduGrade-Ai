<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require_auth();
$attemptId = (int)($_GET['id'] ?? $_POST['attempt_id'] ?? 0);
$attemptStatement = db()->prepare('SELECT a.*,t.title,t.user_id FROM test_attempts a JOIN tests t ON t.id=a.test_id WHERE a.id=? AND t.user_id=?');
$attemptStatement->execute([$attemptId, user()['id']]);
$attempt = $attemptStatement->fetch();
if (!$attempt) { http_response_code(404); exit('Natija topilmadi.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $answerId = (int)($_POST['answer_id'] ?? 0);
    $score = (float)($_POST['manual_score'] ?? -1);
    $feedback = trim((string)($_POST['feedback'] ?? ''));
    $answerStatement = db()->prepare("SELECT sa.id,q.points FROM student_answers sa JOIN questions q ON q.id=sa.question_id JOIN test_attempts a ON a.id=sa.attempt_id JOIN tests t ON t.id=a.test_id WHERE sa.id=? AND sa.attempt_id=? AND q.question_type='written' AND t.user_id=?");
    $answerStatement->execute([$answerId, $attemptId, user()['id']]);
    $answer = $answerStatement->fetch();
    if (!$answer || $score < 0 || $score > (float)$answer['points']) {
        flash('danger', 'Qo‘lda berilgan ball noto‘g‘ri.');
    } else {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $update = $pdo->prepare('UPDATE student_answers SET ai_score=?,ai_feedback=?,requires_review=0 WHERE id=?');
            $update->execute([$score, $feedback !== '' ? $feedback : 'O‘qituvchi tomonidan tekshirildi.', $answerId]);
            $objectiveQuery = $pdo->prepare("SELECT q.id,q.points,GROUP_CONCAT(CASE WHEN o.is_correct=1 THEN o.id END ORDER BY o.id) correct_ids,(SELECT GROUP_CONCAT(sa.option_id ORDER BY sa.option_id) FROM student_answers sa WHERE sa.attempt_id=? AND sa.question_id=q.id AND sa.option_id IS NOT NULL) selected_ids FROM questions q LEFT JOIN options o ON o.question_id=q.id WHERE q.test_id=? AND q.question_type IN ('single','multiple') GROUP BY q.id,q.points");
            $objectiveQuery->execute([$attemptId, $attempt['test_id']]);
            $totalScore = 0.0;
            foreach ($objectiveQuery as $row) if ((string)$row['correct_ids'] === (string)$row['selected_ids']) $totalScore += (float)$row['points'];
            $writtenQuery = $pdo->prepare('SELECT COALESCE(SUM(ai_score),0),COALESCE(MAX(requires_review),0) FROM student_answers WHERE attempt_id=? AND answer_text IS NOT NULL');
            $writtenQuery->execute([$attemptId]);
            [$writtenScore,$pending] = $writtenQuery->fetch(PDO::FETCH_NUM);
            $totalScore += (float)$writtenScore;
            $percentage = (float)$attempt['max_score'] > 0 ? round($totalScore / (float)$attempt['max_score'] * 100, 2) : 0;
            $pdo->prepare('UPDATE test_attempts SET score=?,percentage=?,ai_review_pending=? WHERE id=?')->execute([$totalScore,$percentage,(int)$pending,$attemptId]);
            $pdo->commit(); flash('success', 'Yozma javob bahosi yangilandi.');
        } catch (Throwable $error) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('danger', 'Yangilashda xatolik: '.$error->getMessage()); }
    }
    redirect('attempt-detail.php?id='.$attemptId);
}

$details = db()->prepare("SELECT q.id question_id,q.question_text,q.question_type,q.points,sa.id answer_id,sa.answer_text,sa.ai_score,sa.ai_feedback,sa.ai_confidence,sa.requires_review,o.option_key,o.option_text,o.is_correct,sa.option_id FROM questions q LEFT JOIN student_answers sa ON sa.question_id=q.id AND sa.attempt_id=? LEFT JOIN options o ON o.id=sa.option_id WHERE q.test_id=? ORDER BY q.sort_order,o.sort_order");
$details->execute([$attemptId,$attempt['test_id']]);
$grouped=[]; foreach($details as $row){$qid=$row['question_id'];if(!isset($grouped[$qid]))$grouped[$qid]=['question'=>$row,'answers'=>[]];if($row['answer_id'])$grouped[$qid]['answers'][]=$row;}
render_header('Natija tafsilotlari',true);
?>
<div class="topbar"><div><a href="<?=e(url('results.php?id='.$attempt['test_id']))?>">← Natijalar</a><h1><?=e($attempt['student_first_name'].' '.$attempt['student_last_name'])?></h1><p><?=e($attempt['title'])?> · <?=e($attempt['student_class'])?> · <?=e($attempt['score'])?> / <?=e($attempt['max_score'])?> ball</p></div></div>
<section class="attempt-review-list"><?php $number=0;foreach($grouped as $item):$number++;$q=$item['question'];?><article class="panel attempt-review"><header><span><?=$number?></span><div><h2><?=e($q['question_text'])?></h2><small><?=e($q['points'])?> ball · <?=$q['question_type']==='written'?'AI yozma baholash':'Avtomatik test'?></small></div></header><?php if($q['question_type']==='written'):$answer=$item['answers'][0]??null;?><div class="review-body"><p><b>O‘quvchi javobi:</b><br><?=nl2br(e($answer['answer_text']??'Javob berilmagan'))?></p><?php if($answer):?><p class="ai-feedback">✦ <?=e($answer['ai_feedback'])?></p><form method="post" class="manual-grade"><?=csrf_field()?><input type="hidden" name="attempt_id" value="<?=$attemptId?>"><input type="hidden" name="answer_id" value="<?=$answer['answer_id']?>"><label>Ball<input type="number" name="manual_score" min="0" max="<?=e($q['points'])?>" step="0.01" value="<?=e($answer['ai_score'])?>" required></label><label>O‘qituvchi izohi<input name="feedback" value="<?=e($answer['ai_feedback'])?>"></label><button class="btn primary small">Tasdiqlash</button></form><?php endif?></div><?php else:?><div class="review-body"><p><?php if($item['answers']):foreach($item['answers'] as $answer):?><span class="selected-answer <?=$answer['is_correct']?'correct':'wrong'?>"><?=e($answer['option_key'].') '.$answer['option_text'])?></span><?php endforeach;else:?>Javob berilmagan<?php endif?></p></div><?php endif?></article><?php endforeach?></section>
<?php render_footer(true); ?>
