<?php
declare(strict_types=1); require __DIR__.'/includes/bootstrap.php';
$message='';$ok=false;$envReady=is_file(__DIR__.'/.env');
try {
    if(!$envReady) throw new RuntimeException('.env fayli topilmadi. Avval .env.production.example faylidan .env yarating va hosting ma’lumotlarini kiriting.');
    $pdo=db(true);
    $sql=file_get_contents(__DIR__.'/database/schema.sql');
    if($sql===false) throw new RuntimeException('database/schema.sql fayli o‘qilmadi.');
    $pdo->exec($sql);require_once __DIR__.'/database/migrate_ai.php';run_ai_migration($pdo);
    $ok=true;$message='MySQL ulanishi tekshirildi va barcha jadvallar muvaffaqiyatli o‘rnatildi.';
} catch(Throwable $e) {$message=$e->getMessage();}
?><!doctype html><html lang="uz"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>EduGrade AI Setup</title><link rel="icon" href="<?=e(url('assets/images/favicon.png'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/app.css'))?>"></head><body class="center-page"><div class="setup-card"><div class="status-icon <?=$ok?'ok':'bad'?>"><?=$ok?'✓':'!'?></div><h1><?=$ok?'Server tayyor!':'O‘rnatishda xatolik'?></h1><p><?=e($message)?></p><?php if($ok):?><a class="btn primary" href="<?=e(url())?>">Saytni ochish</a><p class="hint">Xavfsizlik uchun serverdan setup.php faylini o‘chirib qo‘ying.</p><?php else:?><p class="hint">.env ichidagi DB_HOST, DB_NAME, DB_USER va DB_PASS qiymatlarini hosting panelidagi ma’lumotlar bilan tekshiring.</p><?php endif;?></div></body></html>
