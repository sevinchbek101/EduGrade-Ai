# EduGrade AI’ni MySQL hostingga o‘rnatish

## Server talablari

- PHP 8.0 yoki yangiroq (PHP 8.2 tavsiya qilinadi)
- MySQL yoki MariaDB
- PHP kengaytmalari: `pdo_mysql`, `curl`, `zip`, `fileinfo`, `mbstring`
- Apache `mod_rewrite` va `.htaccess` ishlashi
- HTTPS/SSL sertifikati

## 1. MySQL bazasini tayyorlash

Hosting panelida bitta MySQL database va foydalanuvchi yarating. Foydalanuvchiga shu database uchun barcha huquqlarni bering. Hosting ko‘rsatgan DB host, database nomi, username va parolni saqlang.

## 2. Fayllarni yuklash

ZIP ichidagi barcha fayl va papkalarni domenning `public_html` papkasiga chiqaring. `.htaccess` yashirin fayl ekanini unutmang — u ham serverga yuklanishi shart.

## 3. `.env` yaratish

`.env.production.example` faylidan nusxa olib, nusxaning nomini `.env` qiling. Quyidagi qiymatlarni o‘zingiznikiga almashtiring:

```env
APP_URL=https://domeningiz.uz
DB_HOST=localhost
DB_PORT=3306
DB_NAME=hosting_bergan_database_nomi
DB_USER=hosting_bergan_database_user
DB_PASS=hosting_bergan_database_paroli
GEMINI_API_KEY=Gemini_API_kalitingiz
SUPPORT_ADMIN_EMAIL=admin_emailingiz
```

`APP_URL` oxiriga `/` qo‘ymang. Sayt papka ichida bo‘lsa, masalan: `https://domeningiz.uz/test`.

## 4. O‘rnatishni ishga tushirish

Avval brauzerda `https://domeningiz.uz/server-check.php` manzilini oching. PHP 8.0+ va barcha kengaytmalar yashil ko‘rinsa, `https://domeningiz.uz/setup.php` manzilini oching. “Server tayyor!” xabari chiqqach, saytda ro‘yxatdan o‘ting.

## 5. O‘rnatishdan keyingi xavfsizlik

O‘rnatish tugagach `setup.php` va `server-check.php` fayllarini serverdan o‘chiring. `.env` faylini hech kimga yubormang va GitHub’ga joylamang. HTTPS yoqilganini tekshiring.

## Muammo chiqsa

- `Access denied`: DB_USER yoki DB_PASS noto‘g‘ri, yoxud foydalanuvchi databasega biriktirilmagan.
- `Unknown database`: DB_NAME hosting panelidagi to‘liq nom bilan bir xil emas.
- `could not find driver`: `pdo_mysql` yoqilmagan.
- `Call to undefined function curl_init`: PHP cURL yoqilmagan.
- Sahifalar 404 bo‘lsa: `.htaccess` yuklanganini va Apache `mod_rewrite` ishlashini tekshiring.
- HTTP 500 darhol chiqsa: hosting panelidan PHP 8.2 ni tanlang. Keyin `.htaccess` nomini vaqtincha `htaccess-off.txt` qilib, `server-check.php` ni qayta oching. Ochilsa, hosting `.htaccess` qoidalaridan birini qo‘llamayapti.
- Fayl yuklanmasa: hosting PHP sozlamalarida `upload_max_filesize` va `post_max_size` limitlarini tekshiring.
