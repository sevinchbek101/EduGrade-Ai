<?php
declare(strict_types=1);

return [
    'app_name' => 'EduGrade AI',
    'app_url' => rtrim(getenv('APP_URL') ?: 'http://localhost:8000', '/'),
    'support_admin_email' => strtolower(trim(getenv('SUPPORT_ADMIN_EMAIL') ?: '')),
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'port' => getenv('DB_PORT') ?: '3306',
        'name' => getenv('DB_NAME') ?: 'online_test_platform',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
    ],
    'gemini' => [
        'api_key' => getenv('GEMINI_API_KEY') ?: '',
        'relay_url' => trim(getenv('GEMINI_RELAY_URL') ?: ''),
        'relay_token' => trim(getenv('GEMINI_RELAY_TOKEN') ?: ''),
        'model' => getenv('GEMINI_MODEL') ?: 'gemini-3.1-flash-lite',
        'tts_model' => getenv('GEMINI_TTS_MODEL') ?: 'gemini-3.1-flash-tts-preview',
        'thinking_level' => getenv('GEMINI_THINKING_LEVEL') ?: 'low',
        'timeout' => (int)(getenv('GEMINI_TIMEOUT') ?: 135),
    ],
];
