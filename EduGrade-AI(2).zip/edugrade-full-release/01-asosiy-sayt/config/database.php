<?php
declare(strict_types=1);

function db(bool $withDatabase = true): PDO
{
    static $pdo;
    if ($withDatabase && $pdo instanceof PDO) return $pdo;
    $cfg = app_config()['db'];
    $dsn = 'mysql:host=' . $cfg['host'] . ';port=' . $cfg['port'] . ($withDatabase ? ';dbname=' . $cfg['name'] : '') . ';charset=utf8mb4';
    $connection = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    if ($withDatabase) $pdo = $connection;
    return $connection;
}
