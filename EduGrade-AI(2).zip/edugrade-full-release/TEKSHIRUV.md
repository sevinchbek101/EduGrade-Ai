# Tekshiruv natijasi

- Vositachi PHP 7.4.33 WebAssembly muhitida bajarildi: 15 tekshiruv o‘tdi.
- Asosiy saytning AI funksiyalari PHP 8.2 muhitida bajarildi: 16 tekshiruv o‘tdi.
- O‘zgargan 3 ta asosiy PHP fayli va 2 ta vositachi PHP fayli sintaksisi tekshirildi.
- Google transporti testlarda almashtirilgan: haqiqiy API kalit va pullik so‘rov ishlatilmadi.

Vositachi tekshiruvlari: GET, tokensiz/noto‘g‘ri tokenli so‘rov, yaroqsiz JSON,
model mos kelmasligi, ixtiyoriy endpointni rad etish, generation_config
tekshiruvi, muvaffaqiyatli va multimodal so‘rov, hudud xatosi, kvota xatosi,
timeout, JSON bo‘lmagan javob, hajm chegarasi, daqiqalik limit.

Asosiy sayt: relay rejimida Google kalitisiz konfiguratsiya, HTTPS tekshiruvi,
token uzunligi, diagnostika, endpoint/header, Google kaliti yuborilmasligi,
yozma baholash, support, AI yaratish, fayl importi, fayl baytlari saqlanishi,
yaroqsiz javob, xatolardagi tokenni yashirish, qat’iy diagnostika javobi,
bevosita Gemini rejimining saqlanishi.

Hostingning Apache qoidalari, SSL sertifikatlari, tarmoq vaqti cheklovlari,
fayl ruxsatlari va haqiqiy Gemini javoblari shu mahalliy sinov bilan
tasdiqlanmaydi. Bular o‘rnatilgandan keyin tekshiriladi.

## AI Listening uchun hostingdagi yakuniy tekshiruv

1. `Test yaratish` sahifasida mavzu, daraja va savollar sonini kiriting; `AI matn va savollar yaratsin` tugmasini bosing.
2. Tayyor matn va savollarni tekshirib, ovoz/uslub/tezlikni tanlang va `Audio yaratish` tugmasini bosing.
3. Pleerda audioni eshiting, testni nashr qiling va o‘quvchi havolasini oching.
4. O‘quvchi sahifasida audio mavjud, transkript esa yashirin ekanini tekshiring.
5. Xato bo‘lsa asosiy hostingdagi `public/assets/uploads/listening` papkasining yozish ruxsatini va ikkinchi hostingdagi `tts_model` qiymatini tekshiring.
